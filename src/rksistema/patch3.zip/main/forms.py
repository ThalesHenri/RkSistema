from django import forms

from main.models import (
    Categoria,
    UnidadeMedida,
    Produto,
    SKU,
    Parceiro,
    Deposito,
)
from main.models.movimentacao import (
    ORIGEM_MOVIMENTACAO_CHOICES,
    STATUS_PEDIDO_CHOICES,
    FORMA_PAGAMENTO_CHOICES,
)


class BaseModelForm(forms.ModelForm):
    """Aplica a classe .form-control a todos os campos automaticamente."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class CategoriaForm(BaseModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields["categoria_pai"].queryset = Categoria.objects.exclude(pk=self.instance.pk)
        else:
            self.fields["categoria_pai"].queryset = Categoria.objects.all()

    class Meta:
        model = Categoria
        fields = ["nome", "categoria_pai", "ativo"]


class UnidadeMedidaForm(BaseModelForm):
    class Meta:
        model = UnidadeMedida
        fields = ["sigla", "nome"]


class ProdutoForm(BaseModelForm):
    class Meta:
        model = Produto
        fields = ["tipo_produto", "nome", "categoria", "descricao", "ativo"]


class SKUForm(BaseModelForm):
    class Meta:
        model = SKU
        fields = [
            "produto",
            "codigo",
            "codigo_barras",
            "tamanho_capacidade",
            "cor",
            "unidade_medida",
            "estoque_minimo",
            "preco_custo",
            "preco_venda",
            "ativo",
        ]


class ParceiroForm(BaseModelForm):
    class Meta:
        model = Parceiro
        fields = [
            "tipo",
            "razao_social",
            "nome_fantasia",
            "cnpj_cpf",
            "telefone",
            "email",
            "endereco",
            "ativo",
        ]


class DepositoForm(BaseModelForm):
    class Meta:
        model = Deposito
        fields = ["nome", "endereco", "ativo"]


def _queryset_skus():
    return SKU.objects.select_related("produto").order_by("produto__nome", "codigo")


class CampoSkuField(forms.ModelChoiceField):
    """Select de SKU cujo rótulo SEMPRE mostra o código interno, para
    diferenciar variações de um mesmo produto (ex.: PRODUTO — CÓDIGO)."""

    def label_from_instance(self, obj):
        detalhe = " ".join(filter(None, [obj.tamanho_capacidade, obj.cor]))
        rotulo = f"{obj.produto.nome} — {obj.codigo}"
        return f"{rotulo} ({detalhe})" if detalhe else rotulo


class _MovimentacaoForm(forms.Form):
    """Campos comuns de entrada/saída de estoque."""

    sku = CampoSkuField(
        queryset=_queryset_skus(),
        label="SKU",
        help_text="Produto com suas variações (tamanho, cor e código interno).",
    )
    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    quantidade = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01, label="Quantidade"
    )
    origem = forms.ChoiceField(choices=ORIGEM_MOVIMENTACAO_CHOICES, label="Origem")
    parceiro = forms.ModelChoiceField(
        queryset=Parceiro.objects.all(), required=False, label="Cliente (opcional)"
    )
    documento = forms.CharField(required=False, label="Documento (opcional)", help_text="Nº de nota fiscal, pedido etc.")
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class MovimentacaoEntradaForm(_MovimentacaoForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "COMPRA"
        self.fields["parceiro"].label = "Fornecedor (opcional)"


class MovimentacaoSaidaForm(_MovimentacaoForm):
    """Registro de saída com N itens — sem limite fixo de SKUs.

    Cada item tem seu próprio preço unitário negociado (permite cobrar
    preços diferentes para o mesmo produto). As linhas adicionais são
    criadas via JavaScript e lidas dinamicamente do POST com os nomes
    ``sku_{i}`` / ``quantidade_{i}`` / ``preco_unitario_{i}`` (i >= 2).
    """

    LIMITE_ITENS_EXTRAS = 500

    preco_unitario = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0, required=False,
        label="Preço unitário (opcional)",
        help_text="Preço negociado deste item nesta venda. Vazio = usa o preço cadastrado no SKU.",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento (opcional)",
    )
    prazo_pagamento = forms.CharField(
        required=False,
        label="Prazo de pagamento (opcional)",
        help_text="Ex.: 30 dias, à vista, 2x sem juros...",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "VENDA"
        self.fields["parceiro"].label = "Cliente (opcional)"
        self.itens_adicionais = []
        self._adicionar_itens_extras()

    def _adicionar_itens_extras(self):
        """Cria campos para cada linha de item extra realmente enviada no POST."""
        if not self.is_bound:
            return
        for indice in range(2, self.LIMITE_ITENS_EXTRAS + 2):
            if not any(
                f"{nome}_{indice}" in self.data
                for nome in ("sku", "quantidade", "preco_unitario")
            ):
                continue
            self.fields[f"sku_{indice}"] = CampoSkuField(
                queryset=_queryset_skus(), required=False,
                label=f"SKU adicional {indice - 1}",
            )
            self.fields[f"quantidade_{indice}"] = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0.01,
                required=False, label=f"Quantidade adicional {indice - 1}",
            )
            self.fields[f"preco_unitario_{indice}"] = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0,
                required=False, label=f"Preço unitário adicional {indice - 1}",
            )
            for campo_nome in (f"sku_{indice}", f"quantidade_{indice}", f"preco_unitario_{indice}"):
                self.fields[campo_nome].widget.attrs.setdefault("class", "form-control")
            self.itens_adicionais.append(
                (
                    self[f"sku_{indice}"],
                    self[f"quantidade_{indice}"],
                    self[f"preco_unitario_{indice}"],
                )
            )

    def clean(self):
        dados = super().clean()
        # Linha parcialmente preenchida (SKU sem quantidade ou vice-versa) => erro;
        # linha completamente vazia é simplesmente ignorada.
        for indice in range(2, self.LIMITE_ITENS_EXTRAS + 2):
            sku = dados.get(f"sku_{indice}")
            quantidade = dados.get(f"quantidade_{indice}")
            if not sku and not quantidade:
                continue
            if not sku:
                self.add_error(
                    f"sku_{indice}",
                    "Escolha o SKU deste item (ou apague a linha).",
                )
            if not quantidade:
                self.add_error(
                    f"quantidade_{indice}",
                    "Informe a quantidade deste item (ou apague a linha).",
                )
        return dados


class OrcamentoForm(MovimentacaoSaidaForm):
    """Orçamento (pedido simulado): como uma saída, mas não movimenta estoque.

    A origem é fixada em ORCAMENTO (campo desabilitado, não exibido no
    formulário) e o saldo NÃO é validado — um orçamento pode superar o estoque.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "ORCAMENTO"
        self.fields["origem"].disabled = True


class PedidoEditForm(forms.Form):
    """Edição completa de um pedido: cabeçalho + itens (SKU/qtd/preço).

    Os itens usam campos dinâmicos (``sku_{i}``, ``quantidade_{i}``,
    ``preco_unitario_{i}``) para permitir adicionar/remover linhas livremente,
    inclusive a primeira — remover a linha no navegador equivale a removê-la do
    pedido. A lista `linhas_itens` entrega os campos de cada linha ao template.
    """

    LIMITE_ITENS = 500

    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    parceiro = forms.ModelChoiceField(
        queryset=Parceiro.objects.all(), required=False, label="Cliente (opcional)"
    )
    documento = forms.CharField(
        required=False, label="Documento (opcional)",
        help_text="Nº de nota fiscal, pedido etc.",
    )
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )
    status_pedido = forms.ChoiceField(
        required=False,
        choices=[("", "Sem status")] + list(STATUS_PEDIDO_CHOICES),
        label="Status do pedido",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento",
    )
    prazo_pagamento = forms.CharField(required=False, label="Prazo de pagamento")

    def __init__(self, *args, pedido=None, **kwargs):
        if not args and "initial" not in kwargs and pedido is not None:
            kwargs["initial"] = {
                "deposito": pedido.deposito_id,
                "parceiro": pedido.parceiro_id,
                "documento": pedido.documento,
                "observacao": pedido.observacao,
                "status_pedido": pedido.status_pedido or "",
                "forma_pagamento": pedido.forma_pagamento or "",
                "prazo_pagamento": pedido.prazo_pagamento,
            }
        super().__init__(*args, **kwargs)
        self.pedido = pedido
        self.linhas_itens = []
        self._indices = []
        self._itens_existentes = (
            list(pedido.itens.select_related("sku").order_by("id"))
            if pedido is not None else []
        )
        self._definir_itens()
        for campo in self.fields.values():
            campo.widget.attrs.setdefault("class", "form-control")

    def _definir_itens(self):
        """Cria os campos de item a partir do POST (bound) ou dos itens atuais."""
        if self.is_bound:
            indices = [
                indice
                for indice in range(1, self.LIMITE_ITENS + 1)
                if any(
                    f"{nome}_{indice}" in self.data
                    for nome in ("sku", "quantidade", "preco_unitario")
                )
            ]
        else:
            indices = list(range(1, len(self._itens_existentes) + 1))
        if not indices:
            indices = [1]
        for indice in indices:
            self._criar_linha(indice)

    def _criar_linha(self, indice):
        sku_inicial = quantidade_inicial = preco_inicial = None
        if not self.is_bound and indice <= len(self._itens_existentes):
            item = self._itens_existentes[indice - 1]
            sku_inicial = item.sku_id
            quantidade_inicial = item.quantidade
            preco_inicial = item.preco_unitario

        self.fields[f"sku_{indice}"] = CampoSkuField(
            queryset=_queryset_skus(), required=False,
            label=f"SKU {indice}", initial=sku_inicial,
        )
        self.fields[f"quantidade_{indice}"] = forms.DecimalField(
            max_digits=12, decimal_places=2, min_value=0.01, required=False,
            label=f"Quantidade {indice}", initial=quantidade_inicial,
        )
        self.fields[f"preco_unitario_{indice}"] = forms.DecimalField(
            max_digits=12, decimal_places=2, min_value=0, required=False,
            label=f"Preço unitário {indice}", initial=preco_inicial,
        )
        for nome in (f"sku_{indice}", f"quantidade_{indice}", f"preco_unitario_{indice}"):
            self.fields[nome].widget.attrs.setdefault("class", "form-control")

        self._indices.append(indice)
        self.linhas_itens.append(
            {
                "indice": indice,
                "sku": self[f"sku_{indice}"],
                "quantidade": self[f"quantidade_{indice}"],
                "preco_unitario": self[f"preco_unitario_{indice}"],
            }
        )

    def clean(self):
        dados = super().clean()
        completos = 0
        for indice in self._indices:
            sku = dados.get(f"sku_{indice}")
            quantidade = dados.get(f"quantidade_{indice}")
            if not sku and not quantidade:
                continue
            if not sku:
                self.add_error(
                    f"sku_{indice}", "Escolha o SKU deste item (ou remova a linha)."
                )
            if not quantidade:
                self.add_error(
                    f"quantidade_{indice}",
                    "Informe a quantidade deste item (ou remova a linha).",
                )
            if sku and quantidade:
                completos += 1
        if completos == 0:
            raise forms.ValidationError("Informe pelo menos um item para o pedido.")
        return dados

    def itens_validos(self):
        """Itens prontos para o EditarPedidoService, na ordem das linhas."""
        itens = []
        for indice in self._indices:
            sku = self.cleaned_data.get(f"sku_{indice}")
            quantidade = self.cleaned_data.get(f"quantidade_{indice}")
            if not sku or not quantidade:
                continue
            itens.append(
                {
                    "sku": sku,
                    "quantidade": quantidade,
                    "preco_unitario": self.cleaned_data.get(f"preco_unitario_{indice}") or None,
                }
            )
        return itens


class MovimentacaoPrecoStatusForm(forms.Form):
    """Edição rápida de preço, status, forma de pagamento e prazo de uma saída."""

    preco_unitario = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0, required=False,
        label="Preço unitário",
    )
    status_pedido = forms.ChoiceField(
        required=False,
        choices=[("", "Sem status")] + list(STATUS_PEDIDO_CHOICES),
        label="Status do pedido",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento",
    )
    prazo_pagamento = forms.CharField(
        required=False,
        label="Prazo de pagamento",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class ProducaoForm(forms.Form):
    """Formulário de produção: matéria-prima (consumida) → produto em estoque (produzido)."""

    materia_prima = forms.ModelChoiceField(
        queryset=(
            SKU.objects.select_related("produto", "unidade_medida")
            .filter(produto__tipo_produto="MATERIA_PRIMA")
            .order_by("produto__nome", "codigo")
        ),
        label="Matéria-prima (consumida)",
        help_text="SKU que será baixado do estoque.",
    )
    quantidade_materia_prima = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01,
        label="Quantidade consumida",
    )
    produto_acabado = forms.ModelChoiceField(
        queryset=(
            SKU.objects.select_related("produto", "unidade_medida")
            .filter(produto__tipo_produto="PRODUTO_ACABADO")
            .order_by("produto__nome", "codigo")
        ),
        label="Produto em estoque (produzido)",
        help_text="SKU que receberá a entrada no estoque.",
    )
    quantidade_produzida = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01,
        label="Quantidade produzida",
    )
    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    parceiro = forms.ModelChoiceField(
        queryset=Parceiro.objects.filter(tipo__in=("CLIENTE", "AMBOS")),
        required=False,
        label="Cliente (destino) (opcional)",
        help_text=(
            "Se informado, o produto em estoque produzido fica destinado a este "
            "cliente e aparece em Saldos → \"por cliente\"."
        ),
    )
    documento = forms.CharField(
        required=False,
        label="Documento (opcional)",
        help_text="Nº de ordem de produção, nota fiscal etc.",
    )
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")
"""Geração de PDFs de pedidos de clientes (ReportLab).

O "pedido de cliente" é uma movimentação de SAIDA com origem VENDA (ver
registrar_saida_service.py). Este serviço produz dois documentos:

- gerar_pdf_pedido(...)          → PDF individual por pedido com DUAS VIAS na
                                   mesma página (1ª via fica com a empresa;
                                   2ª via para o cliente, destacada e com recibo).
- gerar_pdf_relatorio_pedidos()  → listado filtrável de vários pedidos.

Rode os testes com:
    python manage.py test main.test_pedido_pdf
"""

from datetime import datetime
from decimal import Decimal
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Flowable,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# O documento é impresso em preto e branco para facilitar cópia e arquivamento.
COR_PRIMARIA = colors.black
COR_PRIMARIA_ESCURA = colors.black
COR_DOURADO = colors.white
COR_TEXTO = colors.black
COR_TEXTO_SUAVE = colors.black
COR_BORDA = colors.black
COR_STRIPE = colors.white


class _SeparadorVias(Flowable):
    """Linha pontilhada com tesoura para indicar o corte entre as vias."""

    def __init__(self, largura):
        super().__init__()
        self.width = largura
        self.height = 8 * mm

    def draw(self):
        canvas = self.canv
        centro = self.width / 2
        linha_y = self.height / 2
        raio = 1.5 * mm
        canvas.saveState()
        canvas.setStrokeColor(colors.black)
        canvas.setFillColor(colors.black)
        canvas.setLineWidth(0.6)
        canvas.setDash(1.2, 2.2)
        canvas.line(0, linha_y, centro - 7 * mm, linha_y)
        canvas.line(centro + 7 * mm, linha_y, self.width, linha_y)
        canvas.setDash()

        # Duas alças e lâminas cruzadas formam a tesoura no centro da linha.
        canvas.circle(centro - 2.2 * mm, linha_y + 1.8 * mm, raio, stroke=1, fill=0)
        canvas.circle(centro - 2.2 * mm, linha_y - 1.8 * mm, raio, stroke=1, fill=0)
        canvas.line(centro - 1 * mm, linha_y + 1 * mm, centro + 5 * mm, linha_y + 3 * mm)
        canvas.line(centro - 1 * mm, linha_y - 1 * mm, centro + 5 * mm, linha_y - 3 * mm)
        canvas.restoreState()


def _estilos():
    """Estilos de parágrafo compartilhados pelos documentos."""
    base = getSampleStyleSheet()
    return {
        "marca": ParagraphStyle(
            "marca", parent=base["Normal"], fontName="Helvetica-Bold",
            fontSize=8, leading=10, textColor=COR_PRIMARIA,
        ),
        "titulo": ParagraphStyle(
            "titulo", parent=base["Title"], fontName="Helvetica-Bold",
            fontSize=14, leading=17, textColor=COR_PRIMARIA_ESCURA,
        ),
        "subtitulo": ParagraphStyle(
            "subtitulo", parent=base["Normal"], fontName="Helvetica",
            fontSize=8, leading=10, textColor=COR_TEXTO_SUAVE,
        ),
        "rotulo": ParagraphStyle(
            "rotulo", parent=base["Normal"], fontName="Helvetica-Bold",
            fontSize=7.5, leading=9, textColor=COR_TEXTO_SUAVE,
        ),
        "valor": ParagraphStyle(
            "valor", parent=base["Normal"], fontName="Helvetica",
            fontSize=8.5, leading=10, textColor=COR_TEXTO,
        ),
        "celula": ParagraphStyle(
            "celula", parent=base["Normal"], fontName="Helvetica",
            fontSize=7, leading=8.5,
        ),
        "celula_bold": ParagraphStyle(
            "celula_bold", parent=base["Normal"], fontName="Helvetica-Bold",
            fontSize=7, leading=8.5,
        ),
        "celula_direita": ParagraphStyle(
            "celula_direita", parent=base["Normal"], fontName="Helvetica",
            fontSize=7, leading=8.5, alignment=TA_RIGHT,
        ),
        "celula_bold_direita": ParagraphStyle(
            "celula_bold_direita", parent=base["Normal"], fontName="Helvetica-Bold",
            fontSize=7, leading=8.5, alignment=TA_RIGHT,
        ),
    }


def _nome_usuario(usuario):
    if not usuario:
        return "—"
    return (usuario.get_full_name() or usuario.username).strip() or usuario.username


def _descricao_sku(sku):
    detalhe = " ".join(filter(None, [sku.tamanho_capacidade, sku.cor]))
    base = f"{sku.produto.nome} — {sku.codigo}"
    return f"{base} ({detalhe})" if detalhe else base


def _preco_unitario(movimentacao):
    """Preço unitário negociado na movimentação; senão, preço atual do SKU."""
    if movimentacao.preco_unitario is not None:
        return movimentacao.preco_unitario
    return movimentacao.sku.preco_venda


def _total(movimentacao):
    """Total monetário usando o preço efetivo (negociado ou preço atual do SKU).

    NOTE: a prop `Movimentacao.valor_total` do modelo só considera o preço
    negociado (`preco_unitario`) e retorna None quando ele está vazio — por isso
    aqui recalculamos com _preco_unitario() para o PDF nunca mostrar preço
    unitário sem total correspondente.
    """
    preco = _preco_unitario(movimentacao)
    if preco is None:
        return None
    return preco * movimentacao.quantidade


def _itens_pedido(movimentacao):
    if movimentacao.pedido_id:
        return list(movimentacao.pedido.itens.select_related(
            "sku", "sku__produto", "sku__unidade_medida"
        ).all())
    return [movimentacao]


def _total_pedido(movimentacao):
    totais = [_total(item) for item in _itens_pedido(movimentacao)]
    if any(total is None for total in totais):
        return None
    return sum(totais, Decimal("0"))


def _moeda(valor):
    if valor is None:
        return "—"
    return f"R$ {Decimal(valor):.2f}"


def _cabecalho(titulo, subtitulo):
    """Bloque de cabeçalho comum: marca + título (lista plana de Flowables)."""
    return [
        Paragraph("StockPlastic — Gestão de estoque", _estilos()["marca"]),
        Paragraph(
            f"Emitido: {datetime.now():%d/%m/%Y %H:%M}",
            _estilos()["subtitulo"],
        ),
        Spacer(1, 2 * mm),
        Paragraph(titulo, _estilos()["titulo"]),
        Paragraph(subtitulo, _estilos()["subtitulo"]),
        Spacer(1, 4 * mm),
    ]


def _fila_rotulo_valor(rotulo, valor):
    return [
        Paragraph(rotulo, _estilos()["rotulo"]),
        Paragraph(valor, _estilos()["valor"]),
    ]


def _datos_pedido(movimentacao):
    return [
        _fila_rotulo_valor("Documento", movimentacao.documento or "—"),
        _fila_rotulo_valor(
            "Forma de pagamento",
            movimentacao.get_forma_pagamento_display() or "—",
        ),
        _fila_rotulo_valor(
            "Prazo de pagamento", movimentacao.prazo_pagamento or "—"
        ),
        _fila_rotulo_valor(
            "Data da movimentação",
            f"{movimentacao.data_movimentacao:%d/%m/%Y %H:%M}",
        ),
    ]


def _datos_cliente(parceiro):
    if parceiro is None:
        return [_fila_rotulo_valor("Cliente", "—")]
    linhas = [_fila_rotulo_valor("Cliente", parceiro.razao_social)]
    if parceiro.nome_fantasia:
        linhas.append(_fila_rotulo_valor("Nome fantasia", parceiro.nome_fantasia))
    linhas.append(_fila_rotulo_valor("CNPJ/CPF", parceiro.cnpj_cpf))
    if parceiro.endereco:
        linhas.append(_fila_rotulo_valor("Endereço", parceiro.endereco))
    if parceiro.telefone:
        linhas.append(_fila_rotulo_valor("Telefone", parceiro.telefone))
    if parceiro.email:
        linhas.append(_fila_rotulo_valor("E-mail", parceiro.email))
    return linhas


def _tabla_rotulo_valor(datos, col1, col2):
    tabla = Table(datos, colWidths=[col1, col2])
    tabla.setStyle(
        TableStyle(
            [
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 1),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ]
        )
    )
    return tabla
def _tabla_item(movimentacao):
    s = _estilos()
    cabeceras = [
        Paragraph("Produto / SKU", s["celula_bold"]),
        Paragraph("Unidade", s["celula_bold"]),
        Paragraph("Quantidade", s["celula_bold_direita"]),
        Paragraph("Preço unit.", s["celula_bold_direita"]),
        Paragraph("Total", s["celula_bold_direita"]),
    ]
    filas = [cabeceras]
    for item in _itens_pedido(movimentacao):
        filas.append([
            Paragraph(_descricao_sku(item.sku), s["celula"]),
            Paragraph(item.sku.unidade_medida.sigla, s["celula"]),
            Paragraph(f"{item.quantidade:.2f}", s["celula_direita"]),
            Paragraph(_moeda(_preco_unitario(item)), s["celula_direita"]),
            Paragraph(_moeda(_total(item)), s["celula_bold_direita"]),
        ])
    tabla = Table(
        filas,
        colWidths=[86 * mm, 20 * mm, 22 * mm, 26 * mm, 26 * mm],
    )
    tabla.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.white),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
                ("GRID", (0, 0), (-1, -1), 0.4, COR_BORDA),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return tabla


def _pie_pagina(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(COR_TEXTO_SUAVE)
    canvas.drawCentredString(
        A4[0] / 2,
        9 * mm,
        f"StockPlastic · Página {doc.page} · Emitido {datetime.now():%d/%m/%Y %H:%M}",
    )
    canvas.restoreState()


def _banner_via(rotulo, largura):
    """Faixa monocromática que identifica qual via do pedido é esta."""
    s = _estilos()
    estilo_banner = ParagraphStyle(
        "banner", parent=s["titulo"], fontSize=13, leading=16, textColor=colors.black,
    )
    banner = Table([[Paragraph(rotulo, estilo_banner)]], colWidths=[largura])
    banner.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.black),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    return banner


def _recibo_entrega(movimentacao, largura):
    """Bloco de recibo/assinatura da 2ª via — para destacar na entrega."""
    s = _estilos()
    total = _moeda(_total_pedido(movimentacao))
    estilo_valor = ParagraphStyle(
        "recibo-valor", parent=s["celula_bold"], fontSize=9,
    )
    titulo = Table(
        [[Paragraph("RECIBO DE ENTREGA", estilo_valor)]],
        colWidths=[largura],
    )
    titulo.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.black),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    linhas = [
        [
            Paragraph("Recebido por:", s["celula"]),
            Paragraph("Data: ____/____/____", s["celula"]),
        ],
        [
            Paragraph("Assinatura:", s["celula"]),
            Paragraph("", s["celula"]),
        ],
        [
            Paragraph(f"Valor total: {total}", s["celula"]),
            Paragraph("", s["celula"]),
        ],
    ]
    corpo = Table(linhas, colWidths=[largura * 0.55, largura * 0.45])
    corpo.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, COR_BORDA),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("ROWHEIGHTS", (1, 0), (1, -1), 14),
            ]
        )
    )
    return [titulo, corpo]


def _destaque_orcamento(largura):
    """Aviso destacado de que o documento é um orçamento (sem valor fiscal)."""
    s = _estilos()
    estilo = ParagraphStyle(
        "destaque-orcamento", parent=s["titulo"], fontSize=11, leading=14,
        textColor=colors.black, alignment=TA_CENTER,
    )
    texto = (
        "ORÇAMENTO — DOCUMENTO SEM VALOR FISCAL<br/>"
        "SUJEITO A APROVAÇÃO · NÃO GERA MOVIMENTAÇÃO DE ESTOQUE"
    )
    tabela = Table([[Paragraph(texto, estilo)]], colWidths=[largura])
    tabela.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),
                ("BOX", (0, 0), (-1, -1), 1.4, colors.black),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    return tabela


def _aprovacao_orcamento(movimentacao, largura):
    """Bloco de aprovação da 2ª via de um orçamento (substitui o recibo)."""
    s = _estilos()
    total = _moeda(_total_pedido(movimentacao))
    estilo_valor = ParagraphStyle(
        "aprovacao-valor", parent=s["celula_bold"], fontSize=9,
    )
    titulo = Table(
        [[Paragraph("APROVAÇÃO DO ORÇAMENTO", estilo_valor)]],
        colWidths=[largura],
    )
    titulo.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.black),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    linhas = [
        [
            Paragraph("Aprovado por:", s["celula"]),
            Paragraph("Data: ____/____/____", s["celula"]),
        ],
        [Paragraph("Assinatura:", s["celula"]), Paragraph("", s["celula"])],
        [
            Paragraph(f"Valor total: {total}", s["celula"]),
            Paragraph("", s["celula"]),
        ],
    ]
    corpo = Table(linhas, colWidths=[largura * 0.55, largura * 0.45])
    corpo.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, COR_BORDA),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("ROWHEIGHTS", (1, 0), (1, -1), 14),
            ]
        )
    )
    return [titulo, corpo]


def _total_assinatura(movimentacao, largura, titulo="PREÇO TOTAL DO PEDIDO"):
    """Linha do total e campo de assinatura para qualquer via."""
    s = _estilos()
    total = _moeda(_total_pedido(movimentacao))
    tabela = Table(
        [[
            Paragraph(titulo, s["celula_bold"]),
            Paragraph(total, s["celula_bold_direita"]),
        ], [
            Paragraph("Assinatura: ____________________________________", s["celula"]),
            Paragraph("Data: ____/____/____", s["celula"]),
        ]],
        colWidths=[largura * 0.6, largura * 0.4],
    )
    tabela.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return tabela


def _conteudo_via(movimentacao, usuario, rotulo, largura, segunda_via=False,
                  tipo_documento="PEDIDO"):
    """Flowables de uma via (1ª ou 2ª) do pedido ou do orçamento."""
    s = _estilos()
    eh_orcamento = tipo_documento == "ORCAMENTO"
    conteudo = []

    # Cabeçalho da via: faixa destacada + título + dados em duas colunas
    col = (largura - 4 * mm) / 2
    pedido_col = 32 * mm
    valor_col = col - pedido_col
    esq = _tabla_rotulo_valor(_datos_pedido(movimentacao), pedido_col, valor_col)
    dir_ = _tabla_rotulo_valor(
        _datos_cliente(movimentacao.parceiro), pedido_col, valor_col
    )
    celula_esq = [
        Paragraph("Dados do pedido", s["celula_bold"]),
        Spacer(1, 1 * mm),
        esq,
    ]
    celula_dir = [
        Paragraph("Dados do cliente", s["celula_bold"]),
        Spacer(1, 1 * mm),
        dir_,
    ]
    dupla = Table([[celula_esq, celula_dir]], colWidths=[col, col])
    dupla.setStyle(
        TableStyle(
            [
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, -1), (-1, -1), 4 * mm),
                ("TOPPADDING", (0, 0), (-1, -1), 0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
            ]
        )
    )

    titulo_via = ParagraphStyle(
        "titulo-via", parent=s["titulo"], fontSize=13, leading=16,
        spaceBefore=3 * mm, spaceAfter=1 * mm,
    )

    conteudo.append(_banner_via(rotulo, largura))
    titulo_doc = "Orçamento" if eh_orcamento else "Pedido de cliente"
    conteudo.append(Paragraph(f"{titulo_doc} — Nº #{movimentacao.pk}", titulo_via))
    if eh_orcamento:
        conteudo.append(Spacer(1, 1 * mm))
        conteudo.append(_destaque_orcamento(largura))
    conteudo.append(
        Paragraph(f"Emitido: {datetime.now():%d/%m/%Y %H:%M}", s["subtitulo"])
    )
    conteudo.append(Spacer(1, 1 * mm))
    conteudo.append(dupla)
    conteudo.append(Spacer(1, 2 * mm))
    conteudo.append(
        Paragraph(
            "Detalhes do orçamento" if eh_orcamento else "Detalhes do pedido",
            s["subtitulo"],
        )
    )
    conteudo.append(Spacer(1, 1 * mm))
    conteudo.append(_tabla_item(movimentacao))
    if not segunda_via:
        conteudo.append(Spacer(1, 2 * mm))
        conteudo.append(
            _total_assinatura(
                movimentacao, largura,
                titulo=(
                    "PREÇO TOTAL DO ORÇAMENTO" if eh_orcamento
                    else "PREÇO TOTAL DO PEDIDO"
                ),
            )
        )

    if movimentacao.observacao:
        conteudo.append(Spacer(1, 1 * mm))
        conteudo.append(Paragraph("Observações", s["subtitulo"]))
        conteudo.append(Spacer(1, 1 * mm))
        conteudo.append(Paragraph(movimentacao.observacao, s["valor"]))

    conteudo.append(Spacer(1, 2 * mm))
    conteudo.append(
        Paragraph(f"Gerado por: {_nome_usuario(usuario)}", s["subtitulo"])
    )

    if segunda_via:
        conteudo.append(Spacer(1, 2 * mm))
        if eh_orcamento:
            conteudo.extend(_aprovacao_orcamento(movimentacao, largura))
        else:
            conteudo.extend(_recibo_entrega(movimentacao, largura))

    return conteudo


def gerar_pdf_pedido(movimentacao, usuario=None, tipo_documento="PEDIDO"):
    """Gera o PDF individual de um pedido de cliente ou de um orçamento.

    Produz o documento em UMA ÚNICA PÁGINA:
      - 1ª VIA — fica com a empresa;
      - 2ª VIA — para o cliente, destacada com recibo de entrega (pedido) ou
        bloco de aprovação (orçamento).

    Com `tipo_documento="ORCAMENTO"` o PDF ganha o aviso destacado de que é
    apenas um orçamento, sem valor fiscal.
    """

    eh_orcamento = tipo_documento == "ORCAMENTO"
    margem = 12 * mm
    largura = A4[0] - 2 * margem

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=margem,
        rightMargin=margem,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
        title=f"{'Orçamento' if eh_orcamento else 'Pedido'} #{movimentacao.pk}",
        author="StockPlastic",
        onFirstPage=_pie_pagina,
    )

    if eh_orcamento:
        rotulo_via1 = "1ª VIA — Orçamento (empresa)"
        rotulo_via2 = "2ª VIA — Orçamento (cliente)"
    else:
        rotulo_via1 = "1ª VIA — Fica com a empresa"
        rotulo_via2 = "2ª VIA — Cliente"

    historia = []
    historia.extend(
        _conteudo_via(
            movimentacao, usuario, rotulo_via1, largura,
            tipo_documento=tipo_documento,
        )
    )
    historia.append(_SeparadorVias(largura))
    historia.extend(
        _conteudo_via(
            movimentacao, usuario, rotulo_via2, largura, segunda_via=True,
            tipo_documento=tipo_documento,
        )
    )

    doc.build(historia)
    return buffer.getvalue()


def gerar_pdf_relatorio_pedidos(movimentacoes, filtros=None, usuario=None):
    """Gera o listado de pedidos de clientes filtrável.

    `movimentacoes` é um iterable de Movimentacao (saídas com origem VENDA).
    `filtros` é um dict opcional com chaves: parceiro, status.
    """
    s = _estilos()

    partes_filtro = []
    if filtros and filtros.get("parceiro"):
        partes_filtro.append(f"Cliente: {filtros['parceiro']}")
    if filtros and filtros.get("status"):
        partes_filtro.append(f"Status: {filtros['status']}")
    texto_filtro = " · ".join(partes_filtro) or "Todos os pedidos"

    historia = []
    historia.extend(_cabecalho("Relatório de pedidos de clientes", texto_filtro))
    historia.append(
        Paragraph(
            f"Gerado por: {_nome_usuario(usuario)}",
            s["subtitulo"],
        )
    )
    historia.append(Spacer(1, 4 * mm))

    cabeceras = [
        Paragraph("Data", s["celula_bold"]),
        Paragraph("Nº pedido", s["celula_bold"]),
        Paragraph("Cliente", s["celula_bold"]),
        Paragraph("SKU / Produto", s["celula_bold"]),
        Paragraph("Cant.", s["celula_bold_direita"]),
        Paragraph("Preço unit.", s["celula_bold_direita"]),
        Paragraph("Total", s["celula_bold_direita"]),
        Paragraph("Status", s["celula_bold"]),
    ]
    filas = [cabeceras]

    total_quantidade = Decimal("0")
    total_valor = Decimal("0")
    for m in movimentacoes:
        quantidade_linha = m.quantidade
        total_quantidade += quantidade_linha
        total_linha = _total(m) or Decimal("0")
        total_valor += total_linha
        filas.append(
            [
                Paragraph(f"{m.data_movimentacao:%d/%m/%Y %H:%M}", s["celula"]),
                Paragraph(f"#{m.pk}", s["celula"]),
                Paragraph(m.parceiro.razao_social if m.parceiro else "—", s["celula"]),
                Paragraph(_descricao_sku(m.sku), s["celula"]),
                Paragraph(f"{quantidade_linha:.2f}", s["celula_direita"]),
                Paragraph(_moeda(_preco_unitario(m)), s["celula_direita"]),
                Paragraph(_moeda(total_linha), s["celula_direita"]),
                Paragraph(m.get_status_pedido_display() or "—", s["celula"]),
            ]
        )

    if len(filas) > 1:
        filas.append(
            [
                Paragraph("TOTAL", s["celula_bold"]),
                "",
                "",
                "",
                Paragraph(f"{total_quantidade:.2f}", s["celula_bold_direita"]),
                "",
                Paragraph(_moeda(total_valor), s["celula_bold_direita"]),
                "",
            ]
        )

    tabla = Table(
        filas,
        colWidths=[26 * mm, 16 * mm, 30 * mm, 42 * mm, 14 * mm, 20 * mm, 20 * mm, 16 * mm],
    )
    estilo = [
        ("BACKGROUND", (0, 0), (-1, 0), COR_PRIMARIA),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, COR_BORDA),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if len(filas) > 1:
        estilo.append(
            ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, COR_STRIPE])
        )
        estilo.append(("BACKGROUND", (0, -1), (-1, -1), COR_PRIMARIA_ESCURA))
        estilo.append(("TEXTCOLOR", (0, -1), (-1, -1), colors.white))
    tabla.setStyle(TableStyle(estilo))
    historia.append(tabla)

    if len(filas) == 1:
        historia.append(Spacer(1, 4 * mm))
        historia.append(
            Paragraph("Nenhum pedido coincide com o filtro.", s["subtitulo"])
        )

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=14 * mm,
        rightMargin=14 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title="Relatório de pedidos",
        author="StockPlastic",
        onFirstPage=_pie_pagina,
        onLaterPages=_pie_pagina,
    )
    doc.build(historia)
    return buffer.getvalue()
from collections import defaultdict
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DeleteView, FormView, ListView

from main.forms import (
    MovimentacaoEntradaForm,
    MovimentacaoSaidaForm,
    MovimentacaoPrecoStatusForm,
    ProducaoForm,
)
from main.models import (
    Deposito,
    Movimentacao,
    Parceiro,
    SKU,
    STATUS_PEDIDO_CHOICES,
    FORMA_PAGAMENTO_CHOICES,
    TIPO_PRODUTO_CHOICES,
)
from main.views.services.estoque_error import EstoqueError
from main.views.services.registrar_entrada_service import RegistrarEntradaService
from main.views.services.registrar_saida_service import RegistrarSaidaService
from main.views.services.registrar_producao_service import RegistrarProducaoService


def _calcular_saldos(deposito_id=None):
    """Retorna {sku_id: saldo} considerando entrada/saída/ajustes."""

    movs = Movimentacao.objects.select_related("sku", "deposito")
    if deposito_id:
        movs = movs.filter(deposito_id=deposito_id)

    saldos = defaultdict(Decimal)
    for m in movs.only("sku_id", "deposito_id", "tipo", "quantidade"):
        saldos[m.sku_id] += m.quantidade if m.eh_entrada else -m.quantidade
    return saldos


class MovimentacaoListView(LoginRequiredMixin, ListView):
    model = Movimentacao
    template_name = "main/movimentacao_list.html"
    context_object_name = "movimentacoes"
    paginate_by = 30

    def get_queryset(self):
        qs = (
            Movimentacao.objects.select_related("sku", "sku__produto", "deposito", "parceiro", "usuario")
            .order_by("-data_movimentacao")
        )
        parceiro_id = self.request.GET.get("parceiro")
        if parceiro_id and parceiro_id.isdigit():
            qs = qs.filter(parceiro_id=parceiro_id)
        status_filtro = self.request.GET.get("status")
        if status_filtro in dict(STATUS_PEDIDO_CHOICES):
            qs = qs.filter(status_pedido=status_filtro)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["parceiros"] = Parceiro.objects.all().order_by("razao_social")
        ctx["status_choices"] = STATUS_PEDIDO_CHOICES
        ctx["formas_pagamento"] = FORMA_PAGAMENTO_CHOICES

        parceiro_filtro = None
        parceiro_id = self.request.GET.get("parceiro")
        if parceiro_id and parceiro_id.isdigit():
            parceiro_filtro = Parceiro.objects.filter(pk=parceiro_id).first()
        ctx["parceiro_filtro"] = parceiro_filtro

        status_filtro = self.request.GET.get("status")
        ctx["status_filtro"] = status_filtro if status_filtro in dict(STATUS_PEDIDO_CHOICES) else ""
        return ctx


class EstoqueListView(LoginRequiredMixin, ListView):
    """Saldos de estoque por SKU, com filtro opcional por depósito."""

    model = SKU
    template_name = "main/estoque.html"
    context_object_name = "skus"

    def get_queryset(self):
        qs = SKU.objects.select_related("produto", "unidade_medida").order_by("produto__nome", "codigo")
        tipo_filtro = self.request.GET.get("tipo_produto")
        if tipo_filtro and any(tipo_filtro == valor for valor, _ in TIPO_PRODUTO_CHOICES):
            qs = qs.filter(produto__tipo_produto=tipo_filtro)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)

        deposito_filtro = None
        dep_id = self.request.GET.get("deposito")
        if dep_id and dep_id.isdigit():
            deposito_filtro = Deposito.objects.filter(pk=dep_id).first()

        saldos = _calcular_saldos(deposito_filtro.pk if deposito_filtro else None)

        # detalhamento por depósito (sempre calculado para o filtro atual)
        saldos_por_deposito = defaultdict(dict)
        movs = Movimentacao.objects.select_related("deposito").only(
            "sku_id", "deposito_id", "tipo", "quantidade", "deposito__nome"
        )
        if deposito_filtro:
            movs = movs.filter(deposito=deposito_filtro)
        for m in movs:
            delta = m.quantidade if m.eh_entrada else -m.quantidade
            saldos_por_deposito[m.sku_id][m.deposito_id] = (
                saldos_por_deposito[m.sku_id].get(m.deposito_id, Decimal("0")) + delta
            )
        depositos_ativos = list(Deposito.objects.filter(ativo=True).order_by("nome"))

        linhas = []
        for sku in ctx["object_list"]:
            saldo = saldos.get(sku.pk, Decimal("0"))
            linhas.append(
                {
                    "produto": sku.produto.nome,
                    "tipo": {
                        "label": sku.produto.get_tipo_produto_display(),
                        "classe": (
                            "badge-info"
                            if sku.produto.tipo_produto == "MATERIA_PRIMA"
                            else "badge-ok"
                        ),
                    },
                    "codigo": sku.codigo,
                    "descricao": " ".join(filter(None, [sku.tamanho_capacidade, sku.cor])) or "—",
                    "unidade": sku.unidade_medida.sigla,
                    "saldo": saldo,
                    "estoque_minimo": sku.estoque_minimo,
                    "baixo": saldo <= sku.estoque_minimo,
                    "saldos_depositos": [
                        {
                            "nome": d.nome,
                            "saldo": saldos_por_deposito.get(sku.pk, {}).get(d.pk, Decimal("0")),
                        }
                        for d in depositos_ativos
                    ],
                }
            )

        ctx["linhas"] = linhas
        ctx["depositos"] = Deposito.objects.all().order_by("nome")
        ctx["deposito_filtro"] = deposito_filtro

        ctx["tipos_produto"] = [
            {"pk": valor, "nome": rotulo}
            for valor, rotulo in TIPO_PRODUTO_CHOICES
        ]
        tipo_filtro = self.request.GET.get("tipo_produto")
        ctx["tipo_produto_filtro"] = tipo_filtro if (tipo_filtro and tipo_filtro.isdigit()) else ""

        return ctx


class BaseRegistrarMovimentacaoView(LoginRequiredMixin, FormView):
    """Compartilhado pelas views de entrada e saída."""

    titulo = ""
    mensagem_sucesso = ""

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titulo"] = self.titulo
        return ctx

    def processar(self, dados):
        raise NotImplementedError

    def form_valid(self, form):
        try:
            self.processar(form.cleaned_data)
        except EstoqueError as erro:
            form.add_error(None, str(erro))
            return self.form_invalid(form)
        messages.success(self.request, self.mensagem_sucesso)
        return super().form_valid(form)


class RegistrarEntradaView(BaseRegistrarMovimentacaoView):
    template_name = "main/registrar_movimentacao.html"
    form_class = MovimentacaoEntradaForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar entrada de estoque"
    mensagem_sucesso = "Entrada de estoque registrada com sucesso."

    def processar(self, dados):
        RegistrarEntradaService.executar(
            sku=dados["sku"],
            deposito=dados["deposito"],
            quantidade=dados["quantidade"],
            origem=dados["origem"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            parceiro=dados.get("parceiro"),
            documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
        )


class RegistrarSaidaView(BaseRegistrarMovimentacaoView):
    template_name = "main/saida_movimentacao.html"
    form_class = MovimentacaoSaidaForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar saída de estoque"
    mensagem_sucesso = "Saída de estoque registrada com sucesso."

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Opções de SKU (com código interno) usadas pelo JS para montar as
        # linhas extras do formulário.
        campo_sku = MovimentacaoSaidaForm.base_fields["sku"]
        ctx["skus_opcoes"] = [
            {"pk": sku.pk, "rotulo": campo_sku.label_from_instance(sku)}
            for sku in SKU.objects.select_related("produto").order_by("produto__nome", "codigo")
        ]
        return ctx

    def processar(self, dados):
        itens = [
            {
                "sku": dados["sku"],
                "quantidade": dados["quantidade"],
                "preco_unitario": dados.get("preco_unitario") or None,
            }
        ]
        # Linhas extras vindas do formulário dinâmico — N itens, cada um com
        # o seu próprio preço unitário negociado.
        for indice in range(2, MovimentacaoSaidaForm.LIMITE_ITENS_EXTRAS + 2):
            sku = dados.get(f"sku_{indice}")
            quantidade = dados.get(f"quantidade_{indice}")
            if not sku or not quantidade:
                continue
            itens.append(
                {
                    "sku": sku,
                    "quantidade": quantidade,
                    "preco_unitario": dados.get(f"preco_unitario_{indice}") or None,
                }
            )

        RegistrarSaidaService.executar_varios(
            itens=itens, deposito=dados["deposito"], origem=dados["origem"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            parceiro=dados.get("parceiro"), documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
            forma_pagamento=dados.get("forma_pagamento") or None,
            prazo_pagamento=dados.get("prazo_pagamento") or "",
        )


class AtualizarPrecoStatusView(LoginRequiredMixin, View):
    """Edita preço, status, forma de pagamento e/ou prazo de uma saída."""

    def post(self, request, pk):
        movimentacao = get_object_or_404(Movimentacao, pk=pk)
        if not movimentacao.eh_saida:
            messages.error(
                request,
                "Preço, status e pagamento só se aplicam a movimentações de saída.",
            )
            return redirect("movimentacoes")

        form = MovimentacaoPrecoStatusForm(request.POST)
        if form.is_valid():
            dados = form.cleaned_data
            if dados.get("preco_unitario") is not None:
                movimentacao.preco_unitario = dados["preco_unitario"]
            movimentacao.status_pedido = dados.get("status_pedido") or None
            movimentacao.forma_pagamento = dados.get("forma_pagamento") or None
            movimentacao.prazo_pagamento = dados.get("prazo_pagamento") or ""
            if movimentacao.pedido_id:
                movimentacao.pedido.itens.update(
                    status_pedido=movimentacao.status_pedido,
                    forma_pagamento=movimentacao.forma_pagamento,
                    prazo_pagamento=movimentacao.prazo_pagamento,
                )
            movimentacao.save(
                update_fields=[
                    "preco_unitario", "status_pedido",
                    "forma_pagamento", "prazo_pagamento", "atualizado_em",
                ]
            )
            messages.success(
                request, "Preço/status/pagamento atualizados com sucesso."
            )
        else:
            messages.error(request, "Valores inválidos para preço/status/pagamento.")

        return redirect("movimentacoes")


class RegistrarProducaoView(BaseRegistrarMovimentacaoView):
    template_name = "main/registrar_movimentacao.html"
    form_class = ProducaoForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar produção (matéria-prima → produto em estoque)"
    mensagem_sucesso = (
        "Produção registrada com sucesso: saída da matéria-prima e "
        "entrada do produto em estoque."
    )

    def processar(self, dados):
        RegistrarProducaoService.executar(
            materia_prima=dados["materia_prima"],
            quantidade_materia_prima=dados["quantidade_materia_prima"],
            produto_acabado=dados["produto_acabado"],
            quantidade_produzida=dados["quantidade_produzida"],
            deposito=dados["deposito"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
        )


class MovimentacaoDeleteView(LoginRequiredMixin, DeleteView):
    """Exclui uma movimentação (com página de confirmação).

    No caso de uma produção, a entrada fica vinculada à saída
    (movimentacao_origem); excluímos o PAR junto para o saldo continuar
    consistente. Em qualquer outro caso, apenas a movimentação escolhida é
    removida — o saldo é sempre recalculado a partir do histórico restante.
    """

    model = Movimentacao
    template_name = "main/cadastro_confirm_delete.html"
    titulo = "Excluir movimentação"
    url_lista = "movimentacoes"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titulo"] = self.titulo
        ctx["url_lista"] = self.url_lista
        return ctx

    def get_success_url(self):
        return reverse_lazy("movimentacoes")

    def form_valid(self, form):
        with transaction.atomic():
            alvo = self.get_object()
            pedido = alvo.pedido if alvo.pedido_id else None
            ids = {alvo.pk}
            if alvo.movimentacao_origem_id:
                ids.add(alvo.movimentacao_origem_id)
            # Estornos/vinculados apontam para esta movimentação
            ids.update(alvo.estornos.values_list("id", flat=True))
            if alvo.pedido_id:
                ids.update(alvo.pedido.itens.values_list("id", flat=True))
            # Desfaz o vínculo (movimentacao_origem) antes de apagar, pois o
            # campo é on_delete=PROTECT — evita ProtectedError ao excluir o par.
            Movimentacao.objects.filter(id__in=ids).update(movimentacao_origem=None)
            Movimentacao.objects.filter(id__in=ids).delete()
            if pedido:
                pedido.delete()
        messages.success(self.request, "Movimentação excluída com sucesso.")
        return redirect(self.get_success_url())
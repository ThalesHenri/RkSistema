from collections import defaultdict
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DeleteView, FormView, ListView

from main.forms import (
    MovimentacaoEntradaForm,
    MovimentacaoSaidaForm,
    MovimentacaoPrecoStatusForm,
    OrcamentoForm,
    PedidoEditForm,
    ProducaoForm,
)
from main.models import (
    Deposito,
    Movimentacao,
    Parceiro,
    Pedido,
    SKU,
    STATUS_PEDIDO_CHOICES,
    FORMA_PAGAMENTO_CHOICES,
    TIPO_PRODUTO_CHOICES,
)
from main.views.services.calcular_saldo_service import (
    TIPOS_ENTRADA,
    TIPOS_SAIDA,
    CalcularSaldoService,
)
from main.views.services.estoque_error import EstoqueError
from main.views.services.registrar_entrada_service import RegistrarEntradaService
from main.views.services.registrar_saida_service import RegistrarSaidaService
from main.views.services.registrar_producao_service import RegistrarProducaoService
from main.views.services.registrar_orcamento_service import RegistrarOrcamentoService
from main.views.services.efetivar_orcamento_service import EfetivarOrcamentoService
from main.views.services.excluir_pedido_service import ExcluirPedidoService
from main.views.services.editar_pedido_service import EditarPedidoService


def _delta_saldo(movimentacao):
    """Variação de saldo provocada por uma movimentação.

    Itens de orçamento (e qualquer tipo desconhecido) não alteram o estoque.
    """
    if movimentacao.tipo in TIPOS_ENTRADA:
        return movimentacao.quantidade
    if movimentacao.tipo in TIPOS_SAIDA:
        return -movimentacao.quantidade
    return Decimal("0")


def _calcular_saldos(deposito_id=None):
    """Retorna {sku_id: saldo} considerando entrada/saída/ajustes.

    Orçamentos (tipo ORCAMENTO) são ignorados: não movimentam estoque.
    """

    movs = Movimentacao.objects.select_related("sku", "deposito")
    if deposito_id:
        movs = movs.filter(deposito_id=deposito_id)

    saldos = defaultdict(Decimal)
    for m in movs.only("sku_id", "deposito_id", "tipo", "quantidade"):
        saldos[m.sku_id] += _delta_saldo(m)
    return saldos


def _skus_opcoes(form_class=MovimentacaoSaidaForm):
    """Opções de SKU (com código interno) usadas pelo JS do formulário dinâmico."""
    campo_sku = form_class.base_fields["sku"]
    return [
        {"pk": sku.pk, "rotulo": campo_sku.label_from_instance(sku)}
        for sku in SKU.objects.select_related("produto").order_by("produto__nome", "codigo")
    ]


def _coletar_itens_saida(dados):
    """Itens (SKU/quantidade/preço) do formulário dinâmico de saída/orçamento."""
    itens = [
        {
            "sku": dados["sku"],
            "quantidade": dados["quantidade"],
            "preco_unitario": dados.get("preco_unitario") or None,
        }
    ]
    # Linhas extras: N itens, cada um com o seu próprio preço negociado.
    for indice in range(2, MovimentacaoSaidaForm.LIMITE_ITENS_EXTRAS + 2):
        sku = dados.get(f"sku_{indice}")
        quantidade = dados.get(f"quantidade_{indice}")
        if not sku or not quantidade:
            continue
        itens.append(
            {
                "sku": sku,
                "quantidade": quantidade,
                "preco_unitario": dados.get(f"preco_unitario_{indice}") or None,
            }
        )
    return itens


class MovimentacaoListView(LoginRequiredMixin, ListView):
    model = Movimentacao
    template_name = "main/movimentacao_list.html"
    context_object_name = "movimentacoes"
    paginate_by = 30

    def get_queryset(self):
        qs = (
            Movimentacao.objects.select_related("sku", "sku__produto", "deposito", "parceiro", "usuario")
            .exclude(tipo="ORCAMENTO")  # orçamentos não são movimentações de estoque
            .order_by("-data_movimentacao")
        )
        parceiro_id = self.request.GET.get("parceiro")
        if parceiro_id and parceiro_id.isdigit():
            qs = qs.filter(parceiro_id=parceiro_id)
        status_filtro = self.request.GET.get("status")
        if status_filtro in dict(STATUS_PEDIDO_CHOICES):
            qs = qs.filter(status_pedido=status_filtro)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["parceiros"] = Parceiro.objects.all().order_by("razao_social")
        ctx["status_choices"] = STATUS_PEDIDO_CHOICES
        ctx["formas_pagamento"] = FORMA_PAGAMENTO_CHOICES

        parceiro_filtro = None
        parceiro_id = self.request.GET.get("parceiro")
        if parceiro_id and parceiro_id.isdigit():
            parceiro_filtro = Parceiro.objects.filter(pk=parceiro_id).first()
        ctx["parceiro_filtro"] = parceiro_filtro

        status_filtro = self.request.GET.get("status")
        ctx["status_filtro"] = status_filtro if status_filtro in dict(STATUS_PEDIDO_CHOICES) else ""
        return ctx


class EstoqueListView(LoginRequiredMixin, ListView):
    """Saldos de estoque por SKU, com filtro opcional por depósito."""

    model = SKU
    template_name = "main/estoque.html"
    context_object_name = "skus"

    def get_queryset(self):
        qs = SKU.objects.select_related("produto", "unidade_medida").order_by("produto__nome", "codigo")
        tipo_filtro = self.request.GET.get("tipo_produto")
        if tipo_filtro and any(tipo_filtro == valor for valor, _ in TIPO_PRODUTO_CHOICES):
            qs = qs.filter(produto__tipo_produto=tipo_filtro)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)

        deposito_filtro = None
        dep_id = self.request.GET.get("deposito")
        if dep_id and dep_id.isdigit():
            deposito_filtro = Deposito.objects.filter(pk=dep_id).first()

        saldos = _calcular_saldos(deposito_filtro.pk if deposito_filtro else None)

        # detalhamento por depósito (sempre calculado para o filtro atual)
        saldos_por_deposito = defaultdict(dict)
        movs = Movimentacao.objects.select_related("deposito").only(
            "sku_id", "deposito_id", "tipo", "quantidade", "deposito__nome"
        )
        if deposito_filtro:
            movs = movs.filter(deposito=deposito_filtro)
        for m in movs:
            delta = _delta_saldo(m)
            saldos_por_deposito[m.sku_id][m.deposito_id] = (
                saldos_por_deposito[m.sku_id].get(m.deposito_id, Decimal("0")) + delta
            )
        depositos_ativos = list(Deposito.objects.filter(ativo=True).order_by("nome"))

        # Saldos por cliente: quanto de cada SKU está destinado a cada cliente.
        # destinado = entradas com cliente (ex.: produção para o cliente)
        #           − saídas de venda para esse MESMO cliente.
        # Somente pares (SKU × cliente) que já tiveram estoque destinado entram
        # no painel: uma venda de um SKU nunca destinado ao cliente vem de
        # estoque geral e não deve gerar saldo negativo ("entregue além do
        # destinado"). O negativo só faz sentido quando HOUVE destino antes.
        saldos_por_cliente = defaultdict(lambda: defaultdict(Decimal))
        destinado_por_cliente = defaultdict(lambda: defaultdict(Decimal))
        nomes_clientes = {}
        movs_cliente = Movimentacao.objects.select_related("parceiro").filter(
            parceiro__isnull=False, parceiro__tipo__in=("CLIENTE", "AMBOS"),
        )
        if deposito_filtro:
            movs_cliente = movs_cliente.filter(deposito=deposito_filtro)
        for m in movs_cliente.only(
            "sku_id", "parceiro_id", "tipo", "quantidade",
            "parceiro__razao_social", "parceiro__nome_fantasia",
        ):
            delta = _delta_saldo(m)
            if delta == 0:
                continue
            saldos_por_cliente[m.sku_id][m.parceiro_id] += delta
            if delta > 0:
                destinado_por_cliente[m.sku_id][m.parceiro_id] += delta
            nomes_clientes.setdefault(
                m.parceiro_id,
                m.parceiro.nome_fantasia or m.parceiro.razao_social,
            )

        # Descarta pares sem nenhum estoque destinado (venda pura de estoque
        # geral) para não acusar "entregue além do destinado" indevidamente.
        for sku_id, por_cliente in list(saldos_por_cliente.items()):
            for parceiro_id in list(por_cliente):
                if destinado_por_cliente[sku_id][parceiro_id] == 0:
                    por_cliente.pop(parceiro_id)
            if not por_cliente:
                saldos_por_cliente.pop(sku_id, None)

        # Entradas que compõem o "Destinado" de cada par (SKU × cliente), para
        # a linha do painel poder expandir e desvincular o cliente de cada uma.
        entradas_por_par = defaultdict(list)
        entradas_qs = Movimentacao.objects.filter(
            parceiro__isnull=False, tipo__in=TIPOS_ENTRADA,
        )
        if deposito_filtro:
            entradas_qs = entradas_qs.filter(deposito=deposito_filtro)
        for m in entradas_qs.select_related("deposito").order_by("data_movimentacao"):
            entradas_por_par[(m.sku_id, m.parceiro_id)].append(m)

        linhas = []
        for sku in ctx["object_list"]:
            saldo = saldos.get(sku.pk, Decimal("0"))
            linhas.append(
                {
                    "produto": sku.produto.nome,
                    "tipo": {
                        "label": sku.produto.get_tipo_produto_display(),
                        "classe": (
                            "badge-info"
                            if sku.produto.tipo_produto == "MATERIA_PRIMA"
                            else "badge-ok"
                        ),
                    },
                    "codigo": sku.codigo,
                    "descricao": " ".join(filter(None, [sku.tamanho_capacidade, sku.cor])) or "—",
                    "unidade": sku.unidade_medida.sigla,
                    "saldo": saldo,
                    "estoque_minimo": sku.estoque_minimo,
                    "baixo": saldo <= sku.estoque_minimo,
                    "saldos_depositos": [
                        {
                            "nome": d.nome,
                            "saldo": saldos_por_deposito.get(sku.pk, {}).get(d.pk, Decimal("0")),
                        }
                        for d in depositos_ativos
                    ],
                    "saldos_clientes": [
                        {"cliente": nomes_clientes.get(parceiro_id, "—"), "saldo": valor}
                        for parceiro_id, valor in saldos_por_cliente.get(sku.pk, {}).items()
                    ],
                }
            )

        ctx["linhas"] = linhas
        ctx["depositos"] = Deposito.objects.all().order_by("nome")
        ctx["deposito_filtro"] = deposito_filtro
        ctx["saldos_clientes_painel"] = self._painel_clientes(
            saldos_por_cliente, nomes_clientes, entradas_por_par
        )

        ctx["tipos_produto"] = [
            {"pk": valor, "nome": rotulo}
            for valor, rotulo in TIPO_PRODUTO_CHOICES
        ]
        tipo_filtro = self.request.GET.get("tipo_produto")
        ctx["tipo_produto_filtro"] = tipo_filtro if (tipo_filtro and tipo_filtro.isdigit()) else ""

        return ctx

    def _painel_clientes(self, saldos_por_cliente, nomes_clientes, entradas_por_par):
        """Agrupa os saldos destinados a cada cliente (Cliente → SKU → saldo).

        `saldos_por_cliente` é {sku: {cliente: saldo}} (usado também no detalhe
        por linha do SKU); aqui transponemos para {cliente: {sku: saldo}}.
        `entradas_por_par` é {(sku, cliente): [movimentações]} — as entradas que
        compõem o destinado, exibidas na expansão de cada linha do painel.
        """
        if not saldos_por_cliente:
            return []
        skus = {
            sku.pk: sku
            for sku in SKU.objects.select_related("produto", "unidade_medida")
        }
        transposto = defaultdict(lambda: defaultdict(Decimal))
        for sku_id, por_cliente in saldos_por_cliente.items():
            for parceiro_id, saldo in por_cliente.items():
                transposto[parceiro_id][sku_id] += saldo
        grupos = []
        for parceiro_id, por_sku in transposto.items():
            itens = []
            for sku_id, saldo in por_sku.items():
                sku = skus.get(sku_id)
                if sku is None or saldo == 0:
                    continue
                itens.append(
                    {
                        "sku": sku,
                        "saldo": saldo,
                        "negativo": saldo < 0,
                        "entradas": entradas_por_par.get((sku_id, parceiro_id), []),
                    }
                )
            itens.sort(key=lambda i: (i["sku"].produto.nome, i["sku"].codigo))
            if itens:
                grupos.append(
                    {"cliente": nomes_clientes.get(parceiro_id, "—"), "itens": itens}
                )
        grupos.sort(key=lambda g: g["cliente"])
        return grupos


class BaseRegistrarMovimentacaoView(LoginRequiredMixin, FormView):
    """Compartilhado pelas views de entrada e saída."""

    titulo = ""
    mensagem_sucesso = ""

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titulo"] = self.titulo
        return ctx

    def processar(self, dados):
        raise NotImplementedError

    def form_valid(self, form):
        try:
            self.processar(form.cleaned_data)
        except EstoqueError as erro:
            form.add_error(None, str(erro))
            return self.form_invalid(form)
        messages.success(self.request, self.mensagem_sucesso)
        return super().form_valid(form)


class RegistrarEntradaView(BaseRegistrarMovimentacaoView):
    template_name = "main/registrar_movimentacao.html"
    form_class = MovimentacaoEntradaForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar entrada de estoque"
    mensagem_sucesso = "Entrada de estoque registrada com sucesso."

    def processar(self, dados):
        RegistrarEntradaService.executar(
            sku=dados["sku"],
            deposito=dados["deposito"],
            quantidade=dados["quantidade"],
            origem=dados["origem"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            parceiro=dados.get("parceiro"),
            documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
        )


class RegistrarSaidaView(BaseRegistrarMovimentacaoView):
    template_name = "main/saida_movimentacao.html"
    form_class = MovimentacaoSaidaForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar saída de estoque"
    mensagem_sucesso = "Saída de estoque registrada com sucesso."

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Opções de SKU (com código interno) usadas pelo JS para montar as
        # linhas extras do formulário.
        ctx["skus_opcoes"] = _skus_opcoes(MovimentacaoSaidaForm)
        return ctx

    def processar(self, dados):
        RegistrarSaidaService.executar_varios(
            itens=_coletar_itens_saida(dados),
            deposito=dados["deposito"], origem=dados["origem"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            parceiro=dados.get("parceiro"), documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
            forma_pagamento=dados.get("forma_pagamento") or None,
            prazo_pagamento=dados.get("prazo_pagamento") or "",
        )


class RegistrarOrcamentoView(BaseRegistrarMovimentacaoView):
    """Cria um orçamento (pedido simulado) — não movimenta estoque."""

    template_name = "main/saida_movimentacao.html"
    form_class = OrcamentoForm
    success_url = reverse_lazy("pedidos")
    titulo = "Novo orçamento (pedido simulado)"
    mensagem_sucesso = (
        "Orçamento criado com sucesso. Ele não movimenta o estoque e pode ser "
        "efetivado depois."
    )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["eh_orcamento"] = True
        ctx["skus_opcoes"] = _skus_opcoes(OrcamentoForm)
        return ctx

    def processar(self, dados):
        RegistrarOrcamentoService.executar_varios(
            itens=_coletar_itens_saida(dados),
            deposito=dados["deposito"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            parceiro=dados.get("parceiro"), documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
            forma_pagamento=dados.get("forma_pagamento") or None,
            prazo_pagamento=dados.get("prazo_pagamento") or "",
        )


class AtualizarPrecoStatusView(LoginRequiredMixin, View):
    """Edita preço, status, forma de pagamento e/ou prazo de uma saída."""

    def post(self, request, pk):
        movimentacao = get_object_or_404(Movimentacao, pk=pk)
        if not movimentacao.eh_saida:
            messages.error(
                request,
                "Preço, status e pagamento só se aplicam a movimentações de saída.",
            )
            return redirect("movimentacoes")

        form = MovimentacaoPrecoStatusForm(request.POST)
        if form.is_valid():
            dados = form.cleaned_data
            if dados.get("preco_unitario") is not None:
                movimentacao.preco_unitario = dados["preco_unitario"]
            movimentacao.status_pedido = dados.get("status_pedido") or None
            movimentacao.forma_pagamento = dados.get("forma_pagamento") or None
            movimentacao.prazo_pagamento = dados.get("prazo_pagamento") or ""
            if movimentacao.pedido_id:
                movimentacao.pedido.itens.update(
                    status_pedido=movimentacao.status_pedido,
                    forma_pagamento=movimentacao.forma_pagamento,
                    prazo_pagamento=movimentacao.prazo_pagamento,
                )
            movimentacao.save(
                update_fields=[
                    "preco_unitario", "status_pedido",
                    "forma_pagamento", "prazo_pagamento", "atualizado_em",
                ]
            )
            messages.success(
                request, "Preço/status/pagamento atualizados com sucesso."
            )
        else:
            messages.error(request, "Valores inválidos para preço/status/pagamento.")

        return redirect("movimentacoes")


class RegistrarProducaoView(BaseRegistrarMovimentacaoView):
    template_name = "main/registrar_movimentacao.html"
    form_class = ProducaoForm
    success_url = reverse_lazy("movimentacoes")
    titulo = "Registrar produção (matéria-prima → produto em estoque)"
    mensagem_sucesso = (
        "Produção registrada com sucesso: saída da matéria-prima e "
        "entrada do produto em estoque."
    )

    def processar(self, dados):
        RegistrarProducaoService.executar(
            materia_prima=dados["materia_prima"],
            quantidade_materia_prima=dados["quantidade_materia_prima"],
            produto_acabado=dados["produto_acabado"],
            quantidade_produzida=dados["quantidade_produzida"],
            deposito=dados["deposito"],
            usuario=self.request.user if self.request.user.is_authenticated else None,
            documento=dados.get("documento") or "",
            observacao=dados.get("observacao") or "",
            parceiro=dados.get("parceiro"),
        )


class MovimentacaoDeleteView(LoginRequiredMixin, DeleteView):
    """Exclui uma movimentação (com página de confirmação).

    No caso de uma produção, a entrada fica vinculada à saída
    (movimentacao_origem); excluímos o PAR junto para o saldo continuar
    consistente. Em qualquer outro caso, apenas a movimentação escolhida é
    removida — o saldo é sempre recalculado a partir do histórico restante.
    """

    model = Movimentacao
    template_name = "main/cadastro_confirm_delete.html"
    titulo = "Excluir movimentação"
    url_lista = "movimentacoes"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titulo"] = self.titulo
        ctx["url_lista"] = self.url_lista
        return ctx

    def get_success_url(self):
        return reverse_lazy("movimentacoes")

    def form_valid(self, form):
        with transaction.atomic():
            alvo = self.get_object()
            pedido = alvo.pedido if alvo.pedido_id else None
            ids = {alvo.pk}
            if alvo.movimentacao_origem_id:
                ids.add(alvo.movimentacao_origem_id)
            # Estornos/vinculados apontam para esta movimentação
            ids.update(alvo.estornos.values_list("id", flat=True))
            if alvo.pedido_id:
                ids.update(alvo.pedido.itens.values_list("id", flat=True))
            # Desfaz o vínculo (movimentacao_origem) antes de apagar, pois o
            # campo é on_delete=PROTECT — evita ProtectedError ao excluir o par.
            Movimentacao.objects.filter(id__in=ids).update(movimentacao_origem=None)
            Movimentacao.objects.filter(id__in=ids).delete()
            if pedido:
                pedido.delete()
        messages.success(self.request, "Movimentação excluída com sucesso.")
        return redirect(self.get_success_url())


class EfetivarOrcamentoView(LoginRequiredMixin, View):
    """Converte um orçamento em pedido real (e exclui o orçamento).

    O GET mostra o saldo disponível de cada item (para conferência); o POST
    cria o pedido e remove o orçamento (ver EfetivarOrcamentoService).
    """

    template_name = "main/orcamento_efetivar.html"

    def _contexto(self, pedido):
        itens = list(
            pedido.itens.select_related(
                "sku", "sku__produto", "sku__unidade_medida"
            ).all()
        )
        saldos = {
            sku_id: CalcularSaldoService.executar(sku=sku, deposito=pedido.deposito)
            for sku_id, sku in {item.sku_id: item.sku for item in itens}.items()
        }
        quantidades = defaultdict(Decimal)
        linhas = []
        for item in itens:
            quantidades[item.sku_id] += item.quantidade
            linhas.append({"item": item, "saldo": saldos[item.sku_id]})
        insuficiente = any(
            saldos[sku_id] < quantidade for sku_id, quantidade in quantidades.items()
        )
        return {"pedido": pedido, "linhas": linhas, "insuficiente": insuficiente}

    def get(self, request, pk):
        pedido = get_object_or_404(Pedido, pk=pk)
        if not pedido.eh_orcamento:
            messages.error(request, "Este registro não é um orçamento.")
            return redirect("pedidos")
        return render(request, self.template_name, self._contexto(pedido))

    def post(self, request, pk):
        pedido = get_object_or_404(Pedido, pk=pk)
        numero_orcamento = pedido.pk
        try:
            novo = EfetivarOrcamentoService.executar(
                pedido,
                usuario=request.user if request.user.is_authenticated else None,
            )
        except EstoqueError as erro:
            messages.error(request, f"Não foi possível efetivar o orçamento: {erro}")
            return redirect("orcamento_efetivar", pk=numero_orcamento)
        messages.success(
            request,
            f"Orçamento #{numero_orcamento} efetivado como pedido #{novo.pk}. "
            "O orçamento foi excluído.",
        )
        return redirect("pedidos")


class PedidoDeleteView(LoginRequiredMixin, DeleteView):
    """Exclui um pedido (ou orçamento) e todos os seus itens."""

    model = Pedido
    template_name = "main/cadastro_confirm_delete.html"
    titulo = "Excluir pedido"
    url_lista = "pedidos"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titulo"] = self.titulo
        ctx["url_lista"] = self.url_lista
        return ctx

    def get_success_url(self):
        return reverse_lazy("pedidos")

    def form_valid(self, form):
        pedido = self.get_object()
        numero = pedido.pk
        rotulo = "Orçamento" if pedido.eh_orcamento else "Pedido"
        ExcluirPedidoService.executar(pedido)
        messages.success(self.request, f"{rotulo} #{numero} excluído com sucesso.")
        return redirect(self.get_success_url())


class OrcamentosDeleteView(LoginRequiredMixin, View):
    """Exclui TODOS os orçamentos de uma vez (limpeza do banco de dados)."""

    template_name = "main/cadastro_confirm_delete.html"
    titulo = "Excluir todos os orçamentos"
    url_lista = "pedidos"

    def get(self, request):
        total = Pedido.objects.filter(origem="ORCAMENTO").count()
        return render(
            request,
            self.template_name,
            {
                "titulo": self.titulo,
                "object": f"{total} orçamento(s) cadastrado(s)",
                "url_lista": self.url_lista,
            },
        )

    def post(self, request):
        total = 0
        for pedido in Pedido.objects.filter(origem="ORCAMENTO"):
            ExcluirPedidoService.executar(pedido)
            total += 1
        if total:
            messages.success(
                request, f"{total} orçamento(s) excluído(s) com sucesso."
            )
        else:
            messages.info(request, "Não havia orçamentos para excluir.")
        return redirect("pedidos")


class LimparSaldosClientesView(LoginRequiredMixin, View):
    """Desvincula o cliente de todas as ENTRADAS (zera o painel de saldos).

    Só as entradas (produção/compra destinada, ajustes +) perdem o vínculo:
    as vendas antigas mantêm o cliente nos filtros/relatórios e os saldos
    globais de estoque não mudam (parceiro não entra no cálculo de saldo).
    """

    template_name = "main/cadastro_confirm_delete.html"
    titulo = "Limpar saldos por cliente"
    url_lista = "estoque"

    def get(self, request):
        total = Movimentacao.objects.filter(
            parceiro__isnull=False, tipo__in=TIPOS_ENTRADA
        ).count()
        return render(
            request,
            self.template_name,
            {
                "titulo": self.titulo,
                "object": f"{total} entrada(s) com cliente vinculado",
                "url_lista": self.url_lista,
                "texto_confirmacao": (
                    f"Desvincular o cliente de {total} entrada(s) com cliente "
                    "vinculado? Os saldos por cliente serão zerados e não "
                    "poderão ser desfeitos. Vendas, pedidos e saldos de estoque "
                    "não são afetados."
                ),
                "rotulo_acao": "Desvincular cliente das entradas",
            },
        )

    def post(self, request):
        with transaction.atomic():
            total = Movimentacao.objects.filter(
                parceiro__isnull=False, tipo__in=TIPOS_ENTRADA
            ).update(parceiro=None)
        messages.success(
            request,
            f"{total} entrada(s) desvinculada(s) do cliente. "
            "Saldos por cliente zerados.",
        )
        return redirect("estoque")


class DesvincularClienteEntradaView(LoginRequiredMixin, View):
    """Desvincula o cliente de UMA entrada específica (POST).

    A movimentação continua existindo e o estoque não muda — apenas o par
    (SKU × cliente) deixa de contar no painel "Saldos por cliente".
    """

    def post(self, request, pk):
        mov = get_object_or_404(Movimentacao, pk=pk)
        if mov.tipo not in TIPOS_ENTRADA or not mov.parceiro_id:
            messages.error(
                request,
                "Só é possível desvincular o cliente de uma ENTRADA de estoque.",
            )
        else:
            mov.parceiro = None
            mov.save(update_fields=["parceiro", "atualizado_em"])
            messages.success(
                request,
                "Cliente desvinculado da entrada. Saldo por cliente atualizado.",
            )
        return redirect("estoque")


class PedidoUpdateView(LoginRequiredMixin, View):
    """Edição completa de um pedido: cabeçalho + itens (SKU/qtd/preço)."""

    template_name = "main/pedido_editar.html"

    def _contexto(self, pedido, form):
        return {
            "pedido": pedido,
            "form": form,
            "eh_orcamento": pedido.eh_orcamento,
            "skus_opcoes": _skus_opcoes(),
        }

    def get(self, request, pk):
        pedido = get_object_or_404(Pedido, pk=pk)
        form = PedidoEditForm(pedido=pedido)
        return render(request, self.template_name, self._contexto(pedido, form))

    def post(self, request, pk):
        pedido = get_object_or_404(Pedido, pk=pk)
        form = PedidoEditForm(request.POST, pedido=pedido)
        if form.is_valid():
            try:
                EditarPedidoService.executar(
                    pedido=pedido,
                    dados=form.cleaned_data,
                    itens=form.itens_validos(),
                    usuario=request.user if request.user.is_authenticated else None,
                )
            except EstoqueError as erro:
                form.add_error(None, str(erro))
            else:
                rotulo = "Orçamento" if pedido.eh_orcamento else "Pedido"
                messages.success(
                    request, f"{rotulo} #{pedido.pk} atualizado com sucesso."
                )
                return redirect("pedidos")
        return render(request, self.template_name, self._contexto(pedido, form))
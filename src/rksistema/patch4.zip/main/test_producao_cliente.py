"""
Testes da produção com cliente destino e do painel "Saldos por cliente".

A produção pode informar um cliente (parceiro); o cliente é gravado na ENTRADA
do produto acabado. Em /estoque/, o saldo por cliente de um SKU é:

    destinado (entradas com cliente) − saídas de venda para esse MESMO cliente

apenas para parceiros tipo CLIENTE/AMBOS. Itens de orçamento (delta 0) nunca
entram nessa conta.

Rode com:
    python manage.py test main.test_producao_cliente
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from main.models import Categoria, Deposito, Movimentacao, Parceiro, Produto, SKU, UnidadeMedida
from main.views.services.calcular_saldo_service import CalcularSaldoService
from main.views.services.registrar_entrada_service import RegistrarEntradaService
from main.views.services.registrar_producao_service import RegistrarProducaoService
from main.views.services.registrar_saida_service import RegistrarSaidaService


class ProducaoClienteTestCase(TestCase):
    """Chapa vira caixa destinada a um cliente; vendas abatem o saldo do cliente."""

    @classmethod
    def setUpTestData(cls):
        cls.usuario = get_user_model().objects.create_user(
            username="teste", password="senha123"
        )
        cls.categoria = Categoria.objects.create(nome="Embalagens")
        cls.unidade = UnidadeMedida.objects.create(sigla="UN", nome="Unidade")
        cls.deposito = Deposito.objects.create(nome="Depósito Central")

        cls.produto_mp = Produto.objects.create(
            nome="Chapa de Papelão",
            tipo_produto="MATERIA_PRIMA",
            categoria=cls.categoria,
        )
        cls.produto_pa = Produto.objects.create(
            nome="Caixa de Papelão",
            tipo_produto="PRODUTO_ACABADO",
            categoria=cls.categoria,
        )
        cls.sku_mp = SKU.objects.create(
            produto=cls.produto_mp,
            codigo="CHAPA-PAP-120X80",
            unidade_medida=cls.unidade,
            estoque_minimo=Decimal("10"),
        )
        cls.sku_pa = SKU.objects.create(
            produto=cls.produto_pa,
            codigo="CX-302015",
            unidade_medida=cls.unidade,
            estoque_minimo=Decimal("5"),
        )

        cls.cliente = Parceiro.objects.create(
            tipo="CLIENTE", razao_social="Cliente Alpha Ltda", cnpj_cpf="11111111000111"
        )
        cls.outro_cliente = Parceiro.objects.create(
            tipo="CLIENTE", razao_social="Cliente Beta Ltda", cnpj_cpf="22222222000122"
        )
        cls.fornecedor = Parceiro.objects.create(
            tipo="FORNECEDOR", razao_social="Fornecedor Gama", cnpj_cpf="33333333000133"
        )

        # Estoque de matéria-prima para as produções
        RegistrarEntradaService.executar(
            sku=cls.sku_mp,
            deposito=cls.deposito,
            quantidade=Decimal("100"),
            origem="COMPRA",
            usuario=cls.usuario,
        )

    def _produzir(self, quantidade, cliente=None):
        return RegistrarProducaoService.executar(
            materia_prima=self.sku_mp,
            quantidade_materia_prima=Decimal("10"),
            produto_acabado=self.sku_pa,
            quantidade_produzida=Decimal(quantidade),
            deposito=self.deposito,
            usuario=self.usuario,
            parceiro=cliente,
        )

    def _painel(self, deposito_id=None):
        self.client.force_login(self.usuario)
        url = reverse("estoque")
        if deposito_id:
            url = f"{url}?deposito={deposito_id}"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        return resp.context["saldos_clientes_painel"]

    def _saldo_no_painel(self, painel, cliente, sku):
        for grupo in painel:
            if grupo["cliente"] != str(cliente):
                continue
            for item in grupo["itens"]:
                if item["sku"].pk == sku.pk:
                    return item
        return None

    # --- serviço -----------------------------------------------------------

    def test_producao_carimba_cliente_apenas_na_entrada(self):
        resultado = self._produzir("5", cliente=self.cliente)

        self.assertEqual(resultado["entrada"].parceiro, self.cliente)
        # A baixa da matéria-prima não pertence ao cliente
        self.assertIsNone(resultado["saida"].parceiro)


    # --- painel em /estoque/ -----------------------------------------------

    def test_painel_mostra_saldo_destinado_ao_cliente(self):
        self._produzir("5", cliente=self.cliente)

        item = self._saldo_no_painel(self._painel(), self.cliente, self.sku_pa)
        self.assertIsNotNone(item, "cliente deveria aparecer no painel")
        self.assertEqual(item["saldo"], Decimal("5"))
        self.assertFalse(item["negativo"])

    def test_producao_sem_cliente_nao_aparece_no_painel(self):
        self._produzir("5")
        self.assertEqual(self._painel(), [])

    def test_fornecedor_nao_aparece_no_painel(self):
        self._produzir("5", cliente=self.fornecedor)
        self.assertEqual(self._painel(), [])

    def test_venda_para_o_mesmo_cliente_abate_o_saldo_do_cliente(self):
        self._produzir("5", cliente=self.cliente)
        RegistrarSaidaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("2"),
            origem="VENDA",
            usuario=self.usuario,
            parceiro=self.cliente,
        )

        item = self._saldo_no_painel(self._painel(), self.cliente, self.sku_pa)
        self.assertEqual(item["saldo"], Decimal("3"))
        # O estoque global também foi abatido (2 caixas saíram)
        self.assertEqual(
            CalcularSaldoService.executar(sku=self.sku_pa, deposito=self.deposito),
            Decimal("3"),
        )

    def test_venda_para_outro_ou_sem_cliente_nao_abate(self):
        self._produzir("5", cliente=self.cliente)
        RegistrarSaidaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("2"),
            origem="VENDA",
            usuario=self.usuario,
            parceiro=self.outro_cliente,
        )
        RegistrarSaidaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("1"),
            origem="VENDA",
            usuario=self.usuario,
        )

        item = self._saldo_no_painel(self._painel(), self.cliente, self.sku_pa)
        self.assertEqual(item["saldo"], Decimal("5"))

    def test_entrega_alem_do_destinado_fica_negativa(self):
        # 5 destinados ao cliente + 10 entram sem destino
        self._produzir("5", cliente=self.cliente)
        RegistrarEntradaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("10"),
            origem="OUTRA",
            usuario=self.usuario,
        )
        # vende 8 ao cliente: 5 destinados − 8 = −3 (entregue além do destinado)
        RegistrarSaidaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("8"),
            origem="VENDA",
            usuario=self.usuario,
            parceiro=self.cliente,
        )

        item = self._saldo_no_painel(self._painel(), self.cliente, self.sku_pa)
        self.assertEqual(item["saldo"], Decimal("-3"))
        self.assertTrue(item["negativo"])
        # global: 5 + 10 − 8 = 7
        self.assertEqual(
            CalcularSaldoService.executar(sku=self.sku_pa, deposito=self.deposito),
            Decimal("7"),
        )

    def test_venda_de_sku_nunca_destinado_nao_gera_negativo(self):
        # Estoque geral entra SEM cliente e é vendido AO cliente: nunca houve
        # estoque destinado a ele, entao o par (SKU x cliente) nao pode aparecer
        # no painel nem acusar "entregue alem do destinado".
        RegistrarEntradaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("20"),
            origem="OUTRA",
            usuario=self.usuario,
        )
        RegistrarSaidaService.executar(
            sku=self.sku_pa,
            deposito=self.deposito,
            quantidade=Decimal("8"),
            origem="VENDA",
            usuario=self.usuario,
            parceiro=self.cliente,
        )

        self.assertIsNone(
            self._saldo_no_painel(self._painel(), self.cliente, self.sku_pa),
            "venda de estoque nunca destinado nao deve gerar linha no painel",
        )

    # --- formulário da página de produção -----------------------------------

    def test_pagina_producao_com_cliente_destino(self):
        self.client.force_login(self.usuario)
        resp = self.client.post(
            reverse("movimentacao_producao"),
            {
                "materia_prima": self.sku_mp.id,
                "quantidade_materia_prima": "10",
                "produto_acabado": self.sku_pa.id,
                "quantidade_produzida": "4",
                "deposito": self.deposito.id,
                "parceiro": self.cliente.id,
                "documento": "OP-CLI-01",
            },
        )
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(
            Movimentacao.objects.filter(
                origem="PRODUCAO", tipo="ENTRADA", parceiro=self.cliente
            ).exists(),
            "entrada da produção deveria ficar vinculada ao cliente",
        )

    def test_formulario_producao_oferece_apenas_clientes(self):
        from main.forms import ProducaoForm

        form = ProducaoForm()
        opcoes = {opcao.pk for opcao in form.fields["parceiro"].queryset}
        self.assertEqual(opcoes, {self.cliente.pk, self.outro_cliente.pk})

    def test_producao_sem_cliente_fica_com_parceiro_nulo(self):
        resultado = self._produzir("5")
        self.assertIsNone(resultado["entrada"].parceiro)

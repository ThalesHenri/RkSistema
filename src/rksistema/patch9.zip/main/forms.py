from django import forms

from main.models import (
    Categoria,
    UnidadeMedida,
    Produto,
    SKU,
    Parceiro,
    Deposito,
)
from main.models.movimentacao import (
    ORIGEM_MOVIMENTACAO_CHOICES,
    STATUS_PEDIDO_CHOICES,
    FORMA_PAGAMENTO_CHOICES,
)


class BaseModelForm(forms.ModelForm):
    """Aplica a classe .form-control a todos os campos automaticamente."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class CategoriaForm(BaseModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields["categoria_pai"].queryset = Categoria.objects.exclude(pk=self.instance.pk)
        else:
            self.fields["categoria_pai"].queryset = Categoria.objects.all()

    class Meta:
        model = Categoria
        fields = ["nome", "categoria_pai", "ativo"]


class UnidadeMedidaForm(BaseModelForm):
    class Meta:
        model = UnidadeMedida
        fields = ["sigla", "nome"]


class ProdutoForm(BaseModelForm):
    class Meta:
        model = Produto
        fields = ["tipo_produto", "nome", "categoria", "descricao", "ativo"]


class SKUForm(BaseModelForm):
    class Meta:
        model = SKU
        fields = [
            "produto",
            "codigo",
            "codigo_barras",
            "tamanho_capacidade",
            "cor",
            "unidade_medida",
            "estoque_minimo",
            "preco_custo",
            "preco_venda",
            "ativo",
        ]


class ParceiroForm(BaseModelForm):
    class Meta:
        model = Parceiro
        fields = [
            "tipo",
            "razao_social",
            "nome_fantasia",
            "cnpj_cpf",
            "telefone",
            "email",
            "endereco",
            "ativo",
        ]


class DepositoForm(BaseModelForm):
    class Meta:
        model = Deposito
        fields = ["nome", "endereco", "ativo"]


def _queryset_skus():
    return SKU.objects.select_related("produto").order_by("produto__nome", "codigo")


class CampoSkuField(forms.ModelChoiceField):
    """Select de SKU cujo rótulo SEMPRE mostra o código interno, para
    diferenciar variações de um mesmo produto (ex.: PRODUTO — CÓDIGO)."""

    def label_from_instance(self, obj):
        detalhe = " ".join(filter(None, [obj.tamanho_capacidade, obj.cor]))
        rotulo = f"{obj.produto.nome} — {obj.codigo}"
        return f"{rotulo} ({detalhe})" if detalhe else rotulo


def _rotulo_parceiro(parceiro):
    nomes = [nome for nome in (parceiro.nome_fantasia, parceiro.razao_social) if nome]
    nomes = list(dict.fromkeys(nomes))
    return " — ".join(nomes)


class CampoParceiroField(forms.ModelChoiceField):
    """Mostra nome fantasia e razão social para facilitar a busca do cliente."""

    def label_from_instance(self, obj):
        return _rotulo_parceiro(obj)


class _MovimentacaoForm(forms.Form):
    """Campos comuns de entrada/saída de estoque."""

    sku = CampoSkuField(
        queryset=_queryset_skus(),
        label="SKU",
        help_text="Produto com suas variações (tamanho, cor e código interno).",
    )
    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    quantidade = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01, label="Quantidade"
    )
    origem = forms.ChoiceField(choices=ORIGEM_MOVIMENTACAO_CHOICES, label="Origem")
    parceiro = CampoParceiroField(
        queryset=Parceiro.objects.all(), required=False, label="Cliente (opcional)"
    )
    documento = forms.CharField(required=False, label="Documento (opcional)", help_text="Nº de nota fiscal, pedido etc.")
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class MovimentacaoEntradaForm(_MovimentacaoForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "COMPRA"
        self.fields["parceiro"].label = "Fornecedor (opcional)"


class MovimentacaoSaidaForm(_MovimentacaoForm):
    """Registro de saída com N itens — sem limite fixo de SKUs.

    Cada item tem seu próprio preço unitário negociado (permite cobrar
    preços diferentes para o mesmo produto). As linhas adicionais são
    criadas via JavaScript e lidas dinamicamente do POST com os nomes
    ``sku_{i}`` / ``quantidade_{i}`` / ``preco_unitario_{i}`` (i >= 2).

    Pedido com VÁRIOS CLIENTES: o cliente do cabeçalho (``parceiro``) é o
    "cliente principal" e os demais entram em BLOCOS adicionais, exibidos
    quando a opção "Tem clientes adicionais" é marcada. Cada bloco tem seu
    próprio cliente e seus próprios itens::

        cliente_ad_{b} · sku_{b}_{i} · quantidade_{b}_{i} · preco_unitario_{b}_{i}

    Todos os blocos continuam formando um ÚNICO pedido — e um único PDF.
    O cliente de cada item fica gravado em ``Movimentacao.parceiro``, que é
    o que os filtros de faturamento usam para contabilizar por cliente.
    """

    LIMITE_ITENS_EXTRAS = 500
    LIMITE_CLIENTES_EXTRAS = 50

    preco_unitario = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0, required=False,
        label="Preço unitário (opcional)",
        help_text="Preço negociado deste item nesta venda. Vazio = usa o preço cadastrado no SKU.",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento (opcional)",
    )
    prazo_pagamento = forms.CharField(
        required=False,
        label="Prazo de pagamento (opcional)",
        help_text="Ex.: 30 dias, à vista, 2x sem juros...",
    )
    tem_clientes_adicionais = forms.BooleanField(
        required=False,
        label="Tem clientes adicionais",
        help_text=(
            "Marque quando o mesmo pedido reunir mais de um cliente. "
            "Cada cliente ganha seu próprio bloco com seus itens — todos "
            "continuam em um único pedido (e um único PDF)."
        ),
    )
    reservado = forms.BooleanField(
        required=False,
        label="Retirar do saldo reservado",
        help_text=(
            "Marque para abater os itens dos produtos reservados para o cliente. "
            "Desmarcado: a venda movimenta apenas o estoque geral."
        ),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "VENDA"
        self.fields["parceiro"].queryset = Parceiro.objects.filter(
            tipo__in=("CLIENTE", "AMBOS")
        ).order_by("razao_social")
        self.fields["parceiro"].label = "Cliente (principal)"
        self.fields["parceiro"].help_text = (
            "Cliente principal do pedido. Se houver mais clientes, marque "
            "“Tem clientes adicionais” abaixo."
        )
        self.itens_adicionais = []
        # Blocos de cliente adicional: [{indice, cliente, linhas:[{indice, sku, ...}]}]
        self.blocos = []
        self._blocos_indices = []
        self._linhas_por_bloco = {}
        self._adicionar_itens_extras()
        self._adicionar_blocos_clientes()

    def _adicionar_itens_extras(self):
        """Cria campos para cada linha de item extra realmente enviada no POST."""
        if not self.is_bound:
            return
        for indice in range(2, self.LIMITE_ITENS_EXTRAS + 2):
            if not any(
                f"{nome}_{indice}" in self.data
                for nome in ("sku", "quantidade", "preco_unitario")
            ):
                continue
            self.fields[f"sku_{indice}"] = CampoSkuField(
                queryset=_queryset_skus(), required=False,
                label=f"SKU adicional {indice - 1}",
            )
            self.fields[f"quantidade_{indice}"] = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0.01,
                required=False, label=f"Quantidade adicional {indice - 1}",
            )
            self.fields[f"preco_unitario_{indice}"] = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0,
                required=False, label=f"Preço unitário adicional {indice - 1}",
            )
            for campo_nome in (f"sku_{indice}", f"quantidade_{indice}", f"preco_unitario_{indice}"):
                self.fields[campo_nome].widget.attrs.setdefault("class", "form-control")
            self.itens_adicionais.append(
                (
                    self[f"sku_{indice}"],
                    self[f"quantidade_{indice}"],
                    self[f"preco_unitario_{indice}"],
                )
            )

    # ------------------------------------------------------------------
    # Blocos de cliente adicional (pedido com mais de um cliente)
    # ------------------------------------------------------------------
    def _indices_blocos_enviados(self):
        """Blocos realmente presentes no POST: [(bloco, [linhas])]."""
        if not self.is_bound:
            return []
        chaves = set(self.data.keys())
        enviados = []
        for bloco in range(1, self.LIMITE_CLIENTES_EXTRAS + 1):
            tem_cliente = f"cliente_ad_{bloco}" in chaves
            linhas = [
                linha
                for linha in range(1, self.LIMITE_ITENS_EXTRAS + 2)
                if any(
                    f"{nome}_{bloco}_{linha}" in chaves
                    for nome in ("sku", "quantidade", "preco_unitario")
                )
            ]
            if tem_cliente or linhas:
                enviados.append((bloco, linhas or [1]))
        return enviados

    def _adicionar_blocos_clientes(self):
        """Cria os campos (cliente + itens) de cada bloco enviado no POST."""
        for bloco, linhas in self._indices_blocos_enviados():
            self._criar_bloco(bloco, linhas)

    def _criar_bloco(self, bloco, linhas):
        campo_cliente = CampoParceiroField(
            queryset=Parceiro.objects.filter(tipo__in=("CLIENTE", "AMBOS")).order_by("razao_social"),
            required=False,
            label=f"Cliente adicional {bloco}",
        )
        campo_cliente.widget.attrs.setdefault("class", "form-control")
        self.fields[f"cliente_ad_{bloco}"] = campo_cliente
        self._blocos_indices.append(bloco)

        linhas_criadas = []
        for linha in linhas:
            campos = {}
            for nome, rotulo, minimo in (
                ("sku", f"SKU {bloco}.{linha}", None),
                ("quantidade", f"Quantidade {bloco}.{linha}", 0.01),
                ("preco_unitario", f"Preço unitário {bloco}.{linha}", 0),
            ):
                if nome == "sku":
                    campo = CampoSkuField(
                        queryset=_queryset_skus(), required=False, label=rotulo,
                    )
                else:
                    campo = forms.DecimalField(
                        max_digits=12, decimal_places=2, min_value=minimo,
                        required=False, label=rotulo,
                    )
                campo.widget.attrs.setdefault("class", "form-control")
                self.fields[f"{nome}_{bloco}_{linha}"] = campo
                campos[nome] = self[f"{nome}_{bloco}_{linha}"]
            linhas_criadas.append({"indice": linha, **campos})
            self._linhas_por_bloco.setdefault(bloco, []).append(linha)

        self.blocos.append(
            {
                "indice": bloco,
                "cliente": self[f"cliente_ad_{bloco}"],
                "linhas": linhas_criadas,
            }
        )

    def clean(self):
        dados = super().clean()
        # Linha parcialmente preenchida (SKU sem quantidade ou vice-versa) => erro;
        # linha completamente vazia é simplesmente ignorada.
        for indice in range(2, self.LIMITE_ITENS_EXTRAS + 2):
            sku = dados.get(f"sku_{indice}")
            quantidade = dados.get(f"quantidade_{indice}")
            if not sku and not quantidade:
                continue
            if not sku:
                self.add_error(
                    f"sku_{indice}",
                    "Escolha o SKU deste item (ou apague a linha).",
                )
            if not quantidade:
                self.add_error(
                    f"quantidade_{indice}",
                    "Informe a quantidade deste item (ou apague a linha).",
                )
        self._validar_blocos(dados)
        if dados.get("reservado") and dados.get("origem") != "VENDA":
            self.add_error("reservado", "A reserva explícita só pode ser usada em vendas.")
        if dados.get("reservado") and not dados.get("parceiro") and not self._blocos_validos:
            self.add_error(
                "reservado",
                "Informe um cliente no pedido para fazer uma reserva explícita.",
            )
        return dados

    def _validar_blocos(self, dados):
        """Valida os blocos de cliente adicional.

        A opção "Tem clientes adicionais" é a fonte da verdade: desmarcada,
        os blocos enviados são simplesmente ignorados (o usuário escondeu a
        área). Marcada, cada bloco precisa de cliente e de ao menos um item.
        """
        self._blocos_validos = 0
        if not dados.get("tem_clientes_adicionais"):
            return
        if not self._blocos_indices:
            self.add_error(
                "tem_clientes_adicionais",
                "Adicione ao menos um cliente adicional ou desmarque a opção.",
            )
            return
        for bloco in self._blocos_indices:
            cliente = dados.get(f"cliente_ad_{bloco}")
            completos = 0
            for linha in self._linhas_por_bloco.get(bloco, []):
                sku = dados.get(f"sku_{bloco}_{linha}")
                quantidade = dados.get(f"quantidade_{bloco}_{linha}")
                if not sku and not quantidade:
                    continue
                if not sku:
                    self.add_error(
                        f"sku_{bloco}_{linha}",
                        "Escolha o SKU deste item (ou apague a linha).",
                    )
                if not quantidade:
                    self.add_error(
                        f"quantidade_{bloco}_{linha}",
                        "Informe a quantidade deste item (ou apague a linha).",
                    )
                if sku and quantidade:
                    completos += 1
            if not cliente:
                self.add_error(
                    f"cliente_ad_{bloco}",
                    "Escolha o cliente deste bloco.",
                )
            elif completos == 0:
                self.add_error(
                    f"cliente_ad_{bloco}",
                    "Informe pelo menos um item para este cliente adicional "
                    "(ou remova o bloco).",
                )
            if cliente and completos:
                self._blocos_validos += 1
        if self._blocos_validos == 0:
            self.add_error(
                "tem_clientes_adicionais",
                "Nenhum cliente adicional foi preenchido. Complete ao menos "
                "um bloco ou desmarque a opção.",
            )

    def itens_da_saida(self):
        """Itens prontos para os services, cada um com o seu cliente.

        Ordem: bloco principal (cliente do cabeçalho) e depois os blocos de
        cliente adicional. Retorna listas de dicts no formato
        ``{sku, quantidade, preco_unitario, parceiro}``.
        """
        itens = []
        cliente_principal = self.cleaned_data.get("parceiro")

        # Bloco principal: linha 1 + linhas extras (nomes legados).
        sku = self.cleaned_data.get("sku")
        quantidade = self.cleaned_data.get("quantidade")
        if sku and quantidade:
            itens.append(
                {
                    "sku": sku,
                    "quantidade": quantidade,
                    "preco_unitario": self.cleaned_data.get("preco_unitario") or None,
                    "parceiro": cliente_principal,
                }
            )
        for indice in range(2, self.LIMITE_ITENS_EXTRAS + 2):
            sku = self.cleaned_data.get(f"sku_{indice}")
            quantidade = self.cleaned_data.get(f"quantidade_{indice}")
            if not sku or not quantidade:
                continue
            itens.append(
                {
                    "sku": sku,
                    "quantidade": quantidade,
                    "preco_unitario": self.cleaned_data.get(f"preco_unitario_{indice}") or None,
                    "parceiro": cliente_principal,
                }
            )

        # Blocos de cliente adicional (só quando a opção está marcada).
        if not self.cleaned_data.get("tem_clientes_adicionais"):
            return itens
        for bloco in self._blocos_indices:
            cliente = self.cleaned_data.get(f"cliente_ad_{bloco}")
            if not cliente:
                continue
            for linha in self._linhas_por_bloco.get(bloco, []):
                sku = self.cleaned_data.get(f"sku_{bloco}_{linha}")
                quantidade = self.cleaned_data.get(f"quantidade_{bloco}_{linha}")
                if not sku or not quantidade:
                    continue
                itens.append(
                    {
                        "sku": sku,
                        "quantidade": quantidade,
                        "preco_unitario": self.cleaned_data.get(
                            f"preco_unitario_{bloco}_{linha}"
                        )
                        or None,
                        "parceiro": cliente,
                    }
                )
        return itens


class OrcamentoForm(MovimentacaoSaidaForm):
    """Orçamento (pedido simulado): como uma saída, mas não movimenta estoque.

    A origem é fixada em ORCAMENTO (campo desabilitado, não exibido no
    formulário) e o saldo NÃO é validado — um orçamento pode superar o estoque.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["origem"].initial = "ORCAMENTO"
        self.fields["origem"].disabled = True


class PedidoEditForm(forms.Form):
    """Edição completa de um pedido: cabeçalho + itens (SKU/qtd/preço).

    Os itens usam campos dinâmicos (``sku_{i}``, ``quantidade_{i}``,
    ``preco_unitario_{i}``) para permitir adicionar/remover linhas livremente,
    inclusive a primeira — remover a linha no navegador equivale a removê-la do
    pedido. A lista `linhas_itens` entrega os campos de cada linha ao template.

    Pedidos com VÁRIOS CLIENTES são editados por blocos, igual à criação: o
    cliente do cabeçalho é o principal e cada bloco adicional
    (``cliente_ad_{b}`` + ``sku_{b}_{i}``) traz o cliente e os itens dele.
    """

    LIMITE_ITENS = 500
    LIMITE_CLIENTES_EXTRAS = 50

    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    parceiro = CampoParceiroField(
        queryset=Parceiro.objects.filter(tipo__in=("CLIENTE", "AMBOS")),
        required=False, label="Cliente (principal)"
    )
    documento = forms.CharField(
        required=False, label="Documento (opcional)",
        help_text="Nº de nota fiscal, pedido etc.",
    )
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )
    status_pedido = forms.ChoiceField(
        required=False,
        choices=[("", "Sem status")] + list(STATUS_PEDIDO_CHOICES),
        label="Status do pedido",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento",
    )
    prazo_pagamento = forms.CharField(required=False, label="Prazo de pagamento")
    tem_clientes_adicionais = forms.BooleanField(
        required=False,
        label="Tem clientes adicionais",
        help_text=(
            "Marque quando o mesmo pedido reunir mais de um cliente. "
            "Cada cliente tem seu próprio bloco com seus itens."
        ),
    )
    reservado = forms.BooleanField(
        required=False,
        label="Reserva explícita para cliente",
        help_text=(
            "Somente pedidos marcados como reserva abatirão os itens do saldo "
            "produzido para cada cliente."
        ),
    )

    def __init__(self, *args, pedido=None, **kwargs):
        if not args and "initial" not in kwargs and pedido is not None:
            kwargs["initial"] = {
                "deposito": pedido.deposito_id,
                "parceiro": pedido.parceiro_id,
                "documento": pedido.documento,
                "observacao": pedido.observacao,
                "status_pedido": pedido.status_pedido or "",
                "forma_pagamento": pedido.forma_pagamento or "",
                "prazo_pagamento": pedido.prazo_pagamento,
                "reservado": pedido.reservado,
            }
        super().__init__(*args, **kwargs)
        self.pedido = pedido
        self.linhas_itens = []
        self.blocos = []
        self._indices = []
        self._blocos_indices = []
        self._linhas_por_bloco = {}
        self._itens_existentes = (
            list(pedido.itens.select_related("sku", "parceiro").order_by("id"))
            if pedido is not None else []
        )
        self._definir_itens()
        if self.blocos and not self.is_bound:
            self.fields["tem_clientes_adicionais"].initial = True
        for campo in self.fields.values():
            campo.widget.attrs.setdefault("class", "form-control")

    def _itens_por_bloco(self):
        """(itens do bloco principal, [(cliente, [itens])]) dos itens atuais."""
        principais = []
        adicionais = []
        indice_de = {}
        principal_id = self.pedido.parceiro_id if self.pedido is not None else None
        for item in self._itens_existentes:
            if item.parceiro_id is None or item.parceiro_id == principal_id:
                principais.append(item)
                continue
            if item.parceiro_id not in indice_de:
                indice_de[item.parceiro_id] = len(adicionais)
                adicionais.append((item.parceiro, []))
            adicionais[indice_de[item.parceiro_id]][1].append(item)
        return principais, adicionais

    def _definir_itens(self):
        """Cria os campos de item a partir do POST (bound) ou dos itens atuais."""
        if self.is_bound:
            indices = [
                indice
                for indice in range(1, self.LIMITE_ITENS + 1)
                if any(
                    f"{nome}_{indice}" in self.data
                    for nome in ("sku", "quantidade", "preco_unitario")
                )
            ]
            if not indices:
                indices = [1]
            for indice in indices:
                self._criar_linha(indice)
            self._definir_blocos()
            return

        principais, adicionais = self._itens_por_bloco()
        if not principais:
            principais = [None]
        for item in principais:
            self._criar_linha(len(self._indices) + 1, item)
        for numero, (cliente, itens) in enumerate(adicionais, start=1):
            self._criar_bloco(numero, cliente=cliente, itens=itens)

    def _definir_blocos(self):
        """Recria os blocos de cliente adicional enviados no POST."""
        chaves = set(self.data.keys())
        for bloco in range(1, self.LIMITE_CLIENTES_EXTRAS + 1):
            tem_cliente = f"cliente_ad_{bloco}" in chaves
            linhas = [
                linha
                for linha in range(1, self.LIMITE_ITENS + 1)
                if any(
                    f"{nome}_{bloco}_{linha}" in chaves
                    for nome in ("sku", "quantidade", "preco_unitario")
                )
            ]
            if tem_cliente or linhas:
                self._criar_bloco(bloco, linhas=linhas or [1])

    def _criar_bloco(self, bloco, cliente=None, itens=None, linhas=None):
        """Cria o campo do cliente e os campos de item de UM bloco."""
        campo_cliente = CampoParceiroField(
            queryset=Parceiro.objects.filter(tipo__in=("CLIENTE", "AMBOS")).order_by("razao_social"),
            required=False,
            label=f"Cliente adicional {bloco}",
            initial=cliente.pk if cliente is not None else None,
        )
        campo_cliente.widget.attrs.setdefault("class", "form-control")
        self.fields[f"cliente_ad_{bloco}"] = campo_cliente
        self._blocos_indices.append(bloco)

        if linhas is None:
            linhas = list(range(1, len(itens) + 1)) if itens else [1]

        linhas_criadas = []
        for linha in linhas:
            item = itens[linha - 1] if itens and linha <= len(itens) else None
            campos = {
                "indice": linha,
                "sku": self._campo_item_bloco("sku", bloco, linha, item),
                "quantidade": self._campo_item_bloco("quantidade", bloco, linha, item),
                "preco_unitario": self._campo_item_bloco("preco_unitario", bloco, linha, item),
            }
            linhas_criadas.append(campos)
            self._linhas_por_bloco.setdefault(bloco, []).append(linha)

        self.blocos.append(
            {
                "indice": bloco,
                "cliente": self[f"cliente_ad_{bloco}"],
                "linhas": linhas_criadas,
            }
        )

    def _campo_item_bloco(self, nome, bloco, linha, item=None):
        """Cria e devolve o campo ``{nome}_{bloco}_{linha}`` de um bloco."""
        inicial = None
        if item is not None:
            inicial = {
                "sku": item.sku_id,
                "quantidade": item.quantidade,
                "preco_unitario": item.preco_unitario,
            }[nome]
        if nome == "sku":
            campo = CampoSkuField(
                queryset=_queryset_skus(), required=False,
                label=f"SKU {bloco}.{linha}", initial=inicial,
            )
        elif nome == "quantidade":
            campo = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0.01, required=False,
                label=f"Quantidade {bloco}.{linha}", initial=inicial,
            )
        else:
            campo = forms.DecimalField(
                max_digits=12, decimal_places=2, min_value=0, required=False,
                label=f"Preço unitário {bloco}.{linha}", initial=inicial,
            )
        campo.widget.attrs.setdefault("class", "form-control")
        self.fields[f"{nome}_{bloco}_{linha}"] = campo
        return self[f"{nome}_{bloco}_{linha}"]

    def _criar_linha(self, indice, item=None):
        sku_inicial = quantidade_inicial = preco_inicial = None
        if item is not None:
            sku_inicial = item.sku_id
            quantidade_inicial = item.quantidade
            preco_inicial = item.preco_unitario

        self.fields[f"sku_{indice}"] = CampoSkuField(
            queryset=_queryset_skus(), required=False,
            label=f"SKU {indice}", initial=sku_inicial,
        )
        self.fields[f"quantidade_{indice}"] = forms.DecimalField(
            max_digits=12, decimal_places=2, min_value=0.01, required=False,
            label=f"Quantidade {indice}", initial=quantidade_inicial,
        )
        self.fields[f"preco_unitario_{indice}"] = forms.DecimalField(
            max_digits=12, decimal_places=2, min_value=0, required=False,
            label=f"Preço unitário {indice}", initial=preco_inicial,
        )
        for nome in (f"sku_{indice}", f"quantidade_{indice}", f"preco_unitario_{indice}"):
            self.fields[nome].widget.attrs.setdefault("class", "form-control")

        self._indices.append(indice)
        self.linhas_itens.append(
            {
                "indice": indice,
                "sku": self[f"sku_{indice}"],
                "quantidade": self[f"quantidade_{indice}"],
                "preco_unitario": self[f"preco_unitario_{indice}"],
            }
        )

    def _validar_linhas(self, dados, prefixo, indices):
        """Valida linhas ``{campo}{prefixo}_{indice}``; devolve as completas.

        Linha parcialmente preenchida gera erro; linha vazia é ignorada.
        """
        completos = 0
        for indice in indices:
            sku = dados.get(f"sku{prefixo}_{indice}")
            quantidade = dados.get(f"quantidade{prefixo}_{indice}")
            if not sku and not quantidade:
                continue
            if not sku:
                self.add_error(
                    f"sku{prefixo}_{indice}",
                    "Escolha o SKU deste item (ou remova a linha).",
                )
            if not quantidade:
                self.add_error(
                    f"quantidade{prefixo}_{indice}",
                    "Informe a quantidade deste item (ou remova a linha).",
                )
            if sku and quantidade:
                completos += 1
        return completos

    def clean(self):
        dados = super().clean()
        completos = self._validar_linhas(dados, "", self._indices)

        # Blocos de cliente adicional (só contam com a opção marcada).
        if dados.get("tem_clientes_adicionais"):
            if not self._blocos_indices:
                self.add_error(
                    "tem_clientes_adicionais",
                    "Adicione ao menos um cliente adicional ou desmarque a opção.",
                )
            blocos_ok = 0
            for bloco in self._blocos_indices:
                cliente = dados.get(f"cliente_ad_{bloco}")
                # Prefixo `_{bloco}` produz os nomes reais dos campos do bloco
                # (ex.: ``sku_1_1`` / ``quantidade_1_1``).
                do_bloco = self._validar_linhas(
                    dados, f"_{bloco}", self._linhas_por_bloco.get(bloco, [])
                )
                completos += do_bloco
                if cliente and do_bloco:
                    blocos_ok += 1
                elif not cliente and do_bloco:
                    self.add_error(
                        f"cliente_ad_{bloco}", "Escolha o cliente deste bloco."
                    )
                elif cliente and not do_bloco:
                    self.add_error(
                        f"cliente_ad_{bloco}",
                        "Informe pelo menos um item para este cliente adicional "
                        "(ou remova o bloco).",
                    )
            if self._blocos_indices and blocos_ok == 0:
                self.add_error(
                    "tem_clientes_adicionais",
                    "Nenhum cliente adicional foi preenchido. Complete ao menos "
                    "um bloco ou desmarque a opção.",
                )

        if dados.get("reservado") and (self.pedido is None or self.pedido.origem != "VENDA"):
            self.add_error("reservado", "A reserva explícita só pode ser usada em vendas.")
        if dados.get("reservado"):
            tem_cliente_em_item = bool(dados.get("parceiro")) or any(
                dados.get(f"cliente_ad_{bloco}")
                and any(
                    dados.get(f"sku_{bloco}_{linha}")
                    and dados.get(f"quantidade_{bloco}_{linha}")
                    for linha in self._linhas_por_bloco.get(bloco, [])
                )
                for bloco in (
                    self._blocos_indices
                    if dados.get("tem_clientes_adicionais")
                    else []
                )
            )
            if not tem_cliente_em_item:
                self.add_error(
                    "reservado",
                    "Informe um cliente no pedido para fazer uma reserva explícita.",
                )

        if completos == 0:
            raise forms.ValidationError("Informe pelo menos um item para o pedido.")
        return dados

    def itens_validos(self):
        """Itens prontos para o EditarPedidoService, na ordem das linhas."""
        itens = []
        cliente_principal = self.cleaned_data.get("parceiro")
        for indice in self._indices:
            sku = self.cleaned_data.get(f"sku_{indice}")
            quantidade = self.cleaned_data.get(f"quantidade_{indice}")
            if not sku or not quantidade:
                continue
            itens.append(
                {
                    "sku": sku,
                    "quantidade": quantidade,
                    "preco_unitario": self.cleaned_data.get(f"preco_unitario_{indice}") or None,
                    "parceiro": cliente_principal,
                }
            )

        if not self.cleaned_data.get("tem_clientes_adicionais"):
            return itens
        for bloco in self._blocos_indices:
            cliente = self.cleaned_data.get(f"cliente_ad_{bloco}")
            if not cliente:
                continue
            for linha in self._linhas_por_bloco.get(bloco, []):
                sku = self.cleaned_data.get(f"sku_{bloco}_{linha}")
                quantidade = self.cleaned_data.get(f"quantidade_{bloco}_{linha}")
                if not sku or not quantidade:
                    continue
                itens.append(
                    {
                        "sku": sku,
                        "quantidade": quantidade,
                        "preco_unitario": self.cleaned_data.get(
                            f"preco_unitario_{bloco}_{linha}"
                        )
                        or None,
                        "parceiro": cliente,
                    }
                )
        return itens


class MovimentacaoPrecoStatusForm(forms.Form):
    """Edição rápida de preço, status, forma de pagamento e prazo de uma saída."""

    preco_unitario = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0, required=False,
        label="Preço unitário",
    )
    status_pedido = forms.ChoiceField(
        required=False,
        choices=[("", "Sem status")] + list(STATUS_PEDIDO_CHOICES),
        label="Status do pedido",
    )
    forma_pagamento = forms.ChoiceField(
        required=False,
        choices=[("", "Sem forma definida")] + list(FORMA_PAGAMENTO_CHOICES),
        label="Forma de pagamento",
    )
    prazo_pagamento = forms.CharField(
        required=False,
        label="Prazo de pagamento",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")


class ProducaoForm(forms.Form):
    """Formulário de produção: matéria-prima (consumida) → produto em estoque (produzido)."""

    materia_prima = forms.ModelChoiceField(
        queryset=(
            SKU.objects.select_related("produto", "unidade_medida")
            .filter(produto__tipo_produto="MATERIA_PRIMA")
            .order_by("produto__nome", "codigo")
        ),
        label="Matéria-prima (consumida)",
        help_text="SKU que será baixado do estoque.",
    )
    quantidade_materia_prima = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01,
        label="Quantidade consumida",
    )
    produto_acabado = forms.ModelChoiceField(
        queryset=(
            SKU.objects.select_related("produto", "unidade_medida")
            .filter(produto__tipo_produto="PRODUTO_ACABADO")
            .order_by("produto__nome", "codigo")
        ),
        label="Produto em estoque (produzido)",
        help_text="SKU que receberá a entrada no estoque.",
    )
    quantidade_produzida = forms.DecimalField(
        max_digits=12, decimal_places=2, min_value=0.01,
        label="Quantidade produzida",
    )
    deposito = forms.ModelChoiceField(queryset=Deposito.objects.all(), label="Depósito")
    parceiro = forms.ModelChoiceField(
        queryset=Parceiro.objects.filter(tipo__in=("CLIENTE", "AMBOS")),
        required=False,
        label="Cliente (destino) (opcional)",
        help_text=(
            "Se informado, o produto em estoque produzido fica destinado a este "
            "cliente e aparece em Saldos → \"por cliente\"."
        ),
    )
    documento = forms.CharField(
        required=False,
        label="Documento (opcional)",
        help_text="Nº de ordem de produção, nota fiscal etc.",
    )
    observacao = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 3}),
        required=False,
        label="Observação (opcional)",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            if isinstance(campo.widget, forms.CheckboxInput):
                campo.widget.attrs.setdefault("class", "form-check-input")
            else:
                campo.widget.attrs.setdefault("class", "form-control")